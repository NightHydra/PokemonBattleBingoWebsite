from __future__ import annotations
_B='BaseException'
_A='Exception'
import re
from mambalade.infos import Native
from.core import Object
from.core_tokens import ClassMethodToken,NativeFunctionToken,NativeTypeToken
hierarchy='\nBaseException\n ├── BaseExceptionGroup\n ├── GeneratorExit\n ├── KeyboardInterrupt\n ├── SystemExit\n └── Exception\n      ├── ArithmeticError\n      │    ├── FloatingPointError\n      │    ├── OverflowError\n      │    └── ZeroDivisionError\n      ├── AssertionError\n      ├── AttributeError\n      ├── BufferError\n      ├── EOFError\n      ├── ExceptionGroup [BaseExceptionGroup]\n      ├── ImportError\n      │    └── ModuleNotFoundError\n      ├── LookupError\n      │    ├── IndexError\n      │    └── KeyError\n      ├── MemoryError\n      ├── NameError\n      │    └── UnboundLocalError\n      ├── OSError\n      │    ├── BlockingIOError\n      │    ├── ChildProcessError\n      │    ├── ConnectionError\n      │    │    ├── BrokenPipeError\n      │    │    ├── ConnectionAbortedError\n      │    │    ├── ConnectionRefusedError\n      │    │    └── ConnectionResetError\n      │    ├── FileExistsError\n      │    ├── FileNotFoundError\n      │    ├── InterruptedError\n      │    ├── IsADirectoryError\n      │    ├── NotADirectoryError\n      │    ├── PermissionError\n      │    ├── ProcessLookupError\n      │    └── TimeoutError\n      ├── ReferenceError\n      ├── RuntimeError\n      │    ├── NotImplementedError\n      │    └── RecursionError\n      ├── StopAsyncIteration\n      ├── StopIteration\n      ├── SyntaxError\n      │    └── IndentationError\n      │         └── TabError\n      ├── SystemError\n      ├── TypeError\n      ├── ValueError\n      │    └── UnicodeError\n      │         ├── UnicodeDecodeError\n      │         ├── UnicodeEncodeError\n      │         └── UnicodeTranslateError\n      └── Warning\n           ├── BytesWarning\n           ├── DeprecationWarning\n           ├── EncodingWarning\n           ├── FutureWarning\n           ├── ImportWarning\n           ├── PendingDeprecationWarning\n           ├── ResourceWarning\n           ├── RuntimeWarning\n           ├── SyntaxWarning\n           ├── UnicodeWarning\n           └── UserWarning\n'.strip()
pat=re.compile('\\b(\\w+)')
stack=[(-1,Object)]
builtin_exceptions={}
exc_slots={}
for line in hierarchy.splitlines():
	match=pat.search(line);assert match;name,level=match.group(1),match.start()
	while stack[-1][0]>=level:stack.pop()
	parent=stack[-1][1];builtin_exceptions[name]=t=NativeTypeToken(Native(name),parent.mro if name!='ExceptionGroup'else(builtin_exceptions['BaseExceptionGroup'],*parent.mro),known_slots=exc_slots,unsupported=name.endswith('Group'));stack.append((level,t))
for name in'EnvironmentError IOError WindowsError'.split():builtin_exceptions[name]=builtin_exceptions['OSError']
Exception,BaseException=builtin_exceptions[_A],builtin_exceptions[_B]
__all__=[_B,_A,'builtin_exceptions']