from __future__ import annotations
_A=None
import os.path
from pathlib import Path
from typing import TYPE_CHECKING,ClassVar,Final,final
from textual.app import App,ComposeResult
from textual.containers import Container
from textual.reactive import reactive,var
from textual.widgets import DirectoryTree,Footer,Header
from typing_extensions import override
from.module_viewer import ModuleViewer
if TYPE_CHECKING:from collections.abc import Iterable;from mambalade.globalstate import GlobalState;from mambalade.solver import Solver
class MyDirectoryTree(DirectoryTree):
	def __init__(B,global_state):
		B.a=global_state;C=[]
		for E in B.a.modules.values():
			if E.visitor is _A:continue
			A=E.spec.origin;assert A is not _A;C.append(Path(A))
		F=Path(os.path.commonpath(C));super().__init__(F,id='tree-view');B.set_reactive(type(B).guide_depth,2);D={F,*C};B.valid_paths=D
		for A in C:
			while A.parent not in D:D.add(A.parent);A=A.parent
	@override
	def filter_paths(self,paths):return filter(self.valid_paths.__contains__,paths)
@final
class MambaladeDebugger(App[_A]):
	def __init__(A,solver):B=solver;A.solver=B;A.a=B.global_state;super().__init__()
	CSS_PATH='code_browser.tcss';BINDINGS:ClassVar=[('f','toggle_files','Toggle Files'),('q','quit','Quit')];show_tree=var(True);path:reactive[Path|_A]=reactive(_A)
	def watch_show_tree(A,show_tree):A.set_class(show_tree,'-show-tree')
	def compose(A):
		yield Header()
		with Container():yield MyDirectoryTree(A.a);yield ModuleViewer(A.solver).data_bind(type(A).path)
		yield Footer()
	def on_mount(A):A.query_one(DirectoryTree).focus()
	def on_directory_tree_file_selected(B,event):A=event;A.stop();B.path=A.path
	def action_toggle_files(A):A.show_tree=not A.show_tree
	def watch_path(A,path):
		if path is not _A:A.sub_title=str(path.relative_to(A.a.options.root_dir))