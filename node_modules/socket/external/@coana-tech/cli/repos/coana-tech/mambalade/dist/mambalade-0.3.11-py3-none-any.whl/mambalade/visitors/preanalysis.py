from __future__ import annotations
_E='genexpr'
_D='dictcomp'
_C='setcomp'
_B='listcomp'
_A='lambda'
import ast
from collections import Counter
from typing import TYPE_CHECKING,Final,Literal,TypeAlias,TypeVar,final
from typing_extensions import override
from mambalade.asthelpers import ComprehensionNode,FunctionNode
from mambalade.calls import ParameterList
from mambalade.globalstate import GlobalState
from mambalade.infos import ClassInfo,FunctionInfo,ModuleIdentifier,NamespaceNode,NamespaceNodeInfo,QualifiedNode
from.namespace import NamespaceVisitor
if TYPE_CHECKING:from mambalade.globalstate import GlobalState
_CntName=Literal[_A,_B,_C,_D,_E]
@final
class PreanalysisVisitor(NamespaceVisitor):
	__slots__='a','counts','module_name'
	def __init__(A,module_name,a):super().__init__();A.module_name=module_name;A.a=a;A.counts=Counter()
	_N=TypeVar('_N',bound=ast.AST)
	def _qualify(A,node):return QualifiedNode(node,A.module_name)
	def _get_fqn(A,name):
		match A.scope:
			case'globals':return f"{A.module_name}:{name}"
			case'builtins':raise AssertionError('Builtins should not be named')
			case B:return f"{A.a.node_info[B].fully_qualified_name}.{name}"
	def _get_parent(A):
		if isinstance(A.scope,ast.AST):return A.a.node_info[A.scope]
	def _visit_namespace(A,node,name):A.a.node_info[node]=NamespaceNodeInfo(A._qualify(node),name,A._get_parent(),A._get_fqn(name))
	@override
	def visit_ClassDef(self,node):B=node;A=self;A.a.class_info[B]=ClassInfo(A._qualify(B),B.name,A._get_parent(),A._get_fqn(B.name))
	def _next(B,name):A=name;B.counts[A]+=1;return f"<{A}{B.counts[A]}>"
	def _visit_function(A,node):B=node;C=A._next(_A)if isinstance(B,ast.Lambda)else B.name;A.a.function_info[B]=FunctionInfo(A._qualify(B),C,A._get_parent(),A._get_fqn(C),ParameterList.from_ast(B.args))
	visit_FunctionDef=_visit_function;visit_AsyncFunctionDef=_visit_function;visit_Lambda=_visit_function
	def _visit_comp(B,node):
		match node:
			case ast.ListComp():A=_B
			case ast.SetComp():A=_C
			case ast.DictComp():A=_D
			case ast.GeneratorExp():A=_E
		B._visit_namespace(node,B._next(A))
	visit_ListComp=_visit_comp;visit_SetComp=_visit_comp;visit_DictComp=_visit_comp;visit_GeneratorExp=_visit_comp
	def _mark_generator(A,node):B=A.scope;assert isinstance(B,FunctionNode);A.a.function_info[B].generator=True
	visit_Yield=_mark_generator;visit_YieldFrom=_mark_generator