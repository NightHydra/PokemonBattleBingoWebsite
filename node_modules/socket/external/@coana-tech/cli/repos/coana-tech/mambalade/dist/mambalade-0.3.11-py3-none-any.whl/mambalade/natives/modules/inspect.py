from __future__ import annotations
_A='lambda object: 0'
import logging
from typing import TYPE_CHECKING
from mambalade.natives.builtin_functions import noop,strict_identity_decorator
from mambalade.natives.helpers import native_function,return_unknown,unsupported_native
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.calls import CallData;from mambalade.operations import Operations;from mambalade.tokens import NativeToken
logger=logging.getLogger(__name__)
@native_function('inspect.is<type>',spec=_A)
def inspect_type_predicate(_op,_call):0
@native_function('inspect.get<obj>',spec=_A)
def source_code_get(_op,_call):0
@native_function('inspect.signature',spec='lambda callable, *, follow_wrapped=True, globals=None, locals=None, eval_str=False: 0')
def signature(_op,_call):0
model={f"is{A}":inspect_type_predicate for A in'\nmodule class method function generatorfunction generator\ncoroutinefunction coroutine awaitable asyncgenfunction asyncgen\ntraceback frame code builtin methodwrapper routine abstract\nmethoddescriptor datadescriptor getsetdescriptor memberdescriptor'.split()}|{f"get{A}":source_code_get for A in'doc comments file module sourcefile sourcelines source'.split()}|{A:unsupported_native(f"inspect.{A}",return_unknown)for A in'getclasstree getargvalues getmro getcallargs getclosurevars unwrap getattr_static'.split()}|{'markcoroutinefunction':strict_identity_decorator,'cleandoc':noop,'signature':signature,'getfullargspec':noop,'formatargvalues':noop,'get_annotations':noop,'getframeinfo':noop,'getouterframes':noop,'getinnerframes':noop,'currentframe':noop,'stack':noop,'trace':noop,'getgeneratorstate':noop,'getcoroutinestate':noop,'getasyncgenstate':noop,'getgeneratorlocals':noop,'getcoroutinelocals':noop,'getasyncgenlocals':noop}