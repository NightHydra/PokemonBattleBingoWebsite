from __future__ import annotations
import sys
assert sys.version_info>=(3,10)