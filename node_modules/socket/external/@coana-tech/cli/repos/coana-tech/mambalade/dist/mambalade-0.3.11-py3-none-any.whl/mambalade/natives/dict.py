from __future__ import annotations
_I='Ignoring dict.%s for non-dict %s'
_H='update'
_G='lambda self, key, default=None, /: 2'
_F='__setitem__'
_E='__getitem__'
_D='__init__'
_C='__iter__'
_B='lambda self, /: 1'
_A=None
import enum,logging
from dataclasses import replace
from typing import TYPE_CHECKING,Final,Literal,final
from typing_extensions import override
from mambalade.calls import AbstractArgs
from mambalade.infos import QualifiedNode,SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.token_utils import lookup_attr_mro,object_hashable,type_has_attr
from mambalade.tokens import AccessPathToken,ImmutableToken,ObjectToken,Token,TypeToken,UnknownToken
from mambalade.typing import checked_cast
from mambalade.util import TVL
from mambalade.vars import ConstraintVar,DictKeyVar,PropVar,SeqIndexVar
from.builtin_functions import noop
from.core import Object
from.core_tokens import ClassMethodToken,NativeFunctionToken
from.helpers import NativeType,generic_class_getitem,native_function,native_method,native_type
from.iterator import IteratorToken
from.sequences import Tuple
if TYPE_CHECKING:from mambalade.calls import CallData;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
_update_spec='lambda self, mapping_or_iterable=None, /, **kwargs: 1'
def _item_tup(op,dt):A=dt;A=_unwrap(A);B=ImmutableToken(A,Tuple);op.solver.add_subset_constraint(PropVar(A,SynthProp.DICT_KEYS),SeqIndexVar(B,0));op.solver.add_subset_constraint(PropVar(A,SynthProp.DICT_VAL_ALL),SeqIndexVar(B,1));return B
def dict_setitem(op,di,key,value):
	B=value;A=key
	if isinstance(di,UnpackedDictToken):return
	if not isinstance(A,str):op.inclusion_constraint(A,PropVar(di,SynthProp.DICT_KEYS))
	if B is not _A:C=DictKeyVar(di,A)if isinstance(A,str)else PropVar(di,SynthProp.DICT_VAL_UNKNOWN);op.inclusion_constraint(B,C)
def _unwrap(di):return di.obj if isinstance(di,UnpackedDictToken)else di
@native_type(Object,unsupported_methods='__or__ __ior__'.split())
class Dict(NativeType):
	@native_method(_D,spec=_update_spec)
	@staticmethod
	def init(op,d):_dict_update_common(op,d,_D)
	__class_getitem__=generic_class_getitem
	@native_method(_E,spec='lambda self, key, /: 2')
	@staticmethod
	def getitem(op,d):
		A,B=d.args.args
		if object_hashable(B)is TVL.FALSE:return
		def C(di):
			A=di
			if not isinstance(A,ObjectToken)or Dict not in A.typ.mro:logger.debug('Ignoring dict.__getitem__ for non-dict %s',A);return
			A=_unwrap(A)
			if isinstance(B,str):op.return_value(d,DictKeyVar(A,B));op.return_value(d,PropVar(A,SynthProp.DICT_VAL_UNKNOWN))
			else:op.return_value(d,PropVar(A,SynthProp.DICT_VAL_ALL))
		if isinstance(A,Token|ConstraintVar):op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_DICT__GETITEM__,parent=d.parent),C)
	@native_method(_F,spec='lambda self, key, value, /: 3')
	@staticmethod
	def setitem(op,d):
		C,A,D=d.args.args
		if object_hashable(A)is TVL.FALSE:return
		B=A if isinstance(A,Token|ConstraintVar|str)else _A;E=D if isinstance(D,Token|ConstraintVar)else _A
		if(B is _A or isinstance(B,str))and E is _A or not isinstance(C,Token|ConstraintVar):return
		def F(di):
			if isinstance(di,ObjectToken)and Dict in di.typ.mro:dict_setitem(op,di,B,E)
			else:logger.debug('Ignoring dict.__setitem__ for non-dict %s',di)
		op.forall_constraint_uncached(C,ListenerKey(Listener.NATIVE_DICT__SETITEM__,parent=d.parent),F)
	@native_method('get',spec=_G)
	@staticmethod
	def get(op,d):
		A=d.args;_getitem.impl(op,replace(d,args=AbstractArgs.seq(*A.args[:2])))
		if len(A.args)==3 and isinstance((B:=A.args[2]),Token|ConstraintVar):op.return_value(d,B)
	@native_method('setdefault',spec=_G)
	@staticmethod
	def setdefault(op,d):A,B,*D=d.args.args;E,=D or[_A];C=ListenerKey(Listener.NATIVE_DICT_SETDEFAULT,parent=d.parent);Dict.call_slot(_F,op,replace(d,args=AbstractArgs.seq(A,B,E),parent=C));_getitem.impl(op,replace(d,args=AbstractArgs.seq(A,B),parent=C))
	@native_method('popitem',spec=_B)
	@staticmethod
	def popitem(op,d):
		if isinstance((A:=d.args.args[0]),ObjectToken)and Dict in A.typ.mro:op.return_value(d,_item_tup(op,A))
		else:logger.debug('Ignoring dict.popitem for non-dict %s',A)
	clear=noop
	@native_method('copy',spec=_B)
	@staticmethod
	def copy(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or Dict not in A.typ.mro:logger.debug('Ignoring dict.copy for non-dict %s',A);return
		if isinstance(A,UnpackedDictToken):op.return_value(d,A)
		else:B=Dict.new_instance(op,d);_dict_merge(op,d.callnode,B,A);op.return_value(d,B)
	@native_method(_H,spec=_update_spec)
	@staticmethod
	def update(op,d):_dict_update_common(op,d,_H)
	@ClassMethodToken
	@native_function('dict.fromkeys',spec='lambda cls, keys, value=None, /: 1')
	@staticmethod
	def fromkeys(op,d):
		A=op
		if not isinstance((B:=d.args.args[0]),TypeToken)or Dict not in B.mro:logger.debug('Ignoring dict.fromkeys for non-dict cls %s',B);return
		if d.args.unpack_iter is not _A:A.a.warn_unsupported(d.callnode,'dict.fromkeys with iterable unpacking')
		C=B.new_instance(A,d)
		if len(d.args.args)>=2 and isinstance((D:=d.args.args[1]),Token|ConstraintVar):E=ListenerKey(Listener.NATIVE_DICT_FROMKEYS,parent=d.parent);A.unpack_iterable_into(D,replace(d,res=PropVar(C,SynthProp.DICT_KEYS),parent=E))
		if len(d.args.args)>=3 and isinstance((F:=d.args.args[2]),Token|ConstraintVar):A.inclusion_constraint(F,PropVar(C,SynthProp.DICT_VAL_UNKNOWN))
		A.return_value(d,C)
_getitem=checked_cast(NativeFunctionToken,Dict.known_slots[_E])
Dict.known_slots['pop']=Dict.known_slots['get']
class iter_kind(int,enum.Enum):keys=enum.auto();values=enum.auto();items=enum.auto()
def make_view(kind):
	A=kind
	@native_type(Object,tname=f"dict_{A.name}",unsupported_methods='__len__ __contains__'.split())
	class B(NativeType):
		__new__=noop
		@native_method(_C,spec=_B)
		@staticmethod
		def iter(op,d):
			if isinstance((C:=d.args.args[0]),Token|ConstraintVar):
				def D(view):
					C=view
					match C:
						case ImmutableToken(ObjectToken(F)as D,G)if G is B:
							assert Dict in F.mro
							match A:
								case iter_kind.keys:E=PropVar(D,SynthProp.DICT_KEYS)
								case iter_kind.values:E=PropVar(D,SynthProp.DICT_VAL_ALL)
								case iter_kind.items:E=_item_tup(op,D)
							op.return_value(d,IteratorToken(C,E))
						case _:logger.debug('Ignoring %s.__iter__ for non-view %s',B.kind.name,C)
				op.forall_constraint_uncached(C,ListenerKey(Listener.NATIVE_DICT_VIEW__ITER__,number=A.value,parent=d.parent),D)
	@native_function(f"dict.{A.name}",spec=_B)
	def C(op,d):
		if isinstance((C:=d.args.args[0]),Token|ConstraintVar):
			def D(di):
				if isinstance(di,ObjectToken)and Dict in di.typ.mro:op.return_value(d,ImmutableToken(_unwrap(di),B))
				else:logger.debug(_I,A.name,di)
			op.forall_constraint_uncached(C,ListenerKey(Listener.NATIVE_DICT_VIEW,number=A.value,parent=d.parent),D)
	Dict.known_slots[A.name]=C
	if A==iter_kind.keys:
		@native_function('dict.__iter__',spec=_B)
		def D(op,d):
			if isinstance((A:=d.args.args[0]),Token|ConstraintVar):
				def C(di):
					A=di
					if isinstance(A,ObjectToken)and Dict in A.typ.mro:A=_unwrap(A);op.return_value(d,IteratorToken(ImmutableToken(A,B),PropVar(A,SynthProp.DICT_KEYS)))
					else:logger.debug('Ignoring dict.__iter__ for non-dict %s',A)
				op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_DICT__ITER__,parent=d.parent),C)
		Dict.known_slots[_C]=D
for kind in iter_kind:make_view(kind)
def _dict_update_common(op,d,methname):
	C=methname;A=op;D=d.args
	if not isinstance((B:=D.args[0]),ObjectToken|ConstraintVar):logger.debug('Ignoring dict.%s for non-object %s',C,B);return
	if isinstance(B,ConstraintVar):A.a.warn_unsupported(d.callnode,f"dict.{C} with non-constant self");return
	if Dict not in B.typ.mro:logger.debug(_I,C,B);return
	if isinstance(B,UnpackedDictToken):return
	if D.unpack_iter:A.a.warn_unsupported(d.callnode,f"dict.{C} with iterable unpacking")
	if len(D.args)>1 and isinstance((G:=D.args[1]),Token|ConstraintVar):
		def H(t):
			match t:
				case AccessPathToken()|UnknownToken():pass
				case ObjectToken(E):
					if E is Dict:_dict_merge(A,d.callnode,B,t);return
					D=type_has_attr(E,'keys')
					if D is not TVL.FALSE:_dict_merge(A,d.callnode,B,t)
					if D is not TVL.TRUE:F=' (maybe)'if D is TVL.MAYBE else'';A.a.warn_unsupported(d.callnode,f"dict.{C} with iterable of tuples{F}")
		A.forall_constraint_uncached(G,ListenerKey(Listener.NATIVE_DICT_UPDATE_ARG,parent=d.parent),H)
	if(I:=D.kwargs):
		def J(t):
			match t:
				case AccessPathToken()|UnknownToken():pass
				case ObjectToken(D):
					if Dict in D.mro:_dict_merge(A,d.callnode,B,t)
					else:A.a.warn_unsupported(d.callnode,f"Unsupported **unpacking of non-dict in dict.{C}")
		K=ListenerKey(Listener.NATIVE_DICT_UPDATE_KWARGS,parent=d.parent)
		for(F,E)in I:
			if not isinstance(E,Token|ConstraintVar):continue
			if F is _A:A.forall_constraint_uncached(E,K,J)
			else:A.inclusion_constraint(E,DictKeyVar(B,F))
def _dict_merge(op,callnode,di,other):
	B=callnode;A=other;assert Dict in di.typ.mro and not isinstance(di,UnpackedDictToken);A=_unwrap(A);C=Dict in A.typ.mro
	if C and lookup_attr_mro(A.typ,_C)==[Dict.known_slots[_C]]:op.solver.add_subset_constraint(PropVar(A,SynthProp.DICT_KEYS),PropVar(di,SynthProp.DICT_KEYS));op.solver.add_subset_constraint(PropVar(A,SynthProp.DICT_VAL_ALL),PropVar(di,SynthProp.DICT_VAL_UNKNOWN))
	elif C:op.a.warn_unsupported(B,'Dict merge with overridden __iter__')
	else:op.a.warn_unsupported(B,'Dictionary merge with non-dict mapping')
@final
class UnpackedDictToken(ObjectToken):
	immutable=True;typ=Dict;__match_args__='obj',
	def __init__(A,dict):assert type(dict)is not UnpackedDictToken and dict.typ is Dict;A.obj=dict
	@override
	def __str__(self):return f"UnpackedDictToken({self.obj})"
	@override
	def __eq__(B,A):return isinstance(A,UnpackedDictToken)and B.obj==A.obj
	@override
	def __hash__(self):return hash((type(self),self.obj))
	@override
	def _lookup_attr(A,B):return _A,False