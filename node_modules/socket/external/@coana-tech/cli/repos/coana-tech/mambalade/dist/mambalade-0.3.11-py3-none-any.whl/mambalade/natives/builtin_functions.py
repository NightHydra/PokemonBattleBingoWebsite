from __future__ import annotations
_G='lambda: 0'
_F='lambda self, key, default=None, /: 2'
_E='__setitem__'
_D='lambda obj, /: 0'
_C='__getitem__'
_B='Ignoring non-object target %s'
_A=None
import logging
from dataclasses import replace
from typing import TYPE_CHECKING,Final,assert_type
from mambalade.accesspathmanager import ReadAccessPath
from mambalade.asthelpers import FunctionNode
from mambalade.calls import AbstractArgs,CallData
from mambalade.infos import ModuleIdentifier,Native,NodeSource,source_module
from mambalade.listeners import Listener,ListenerKey
from mambalade.token_utils import lookup_attr_mro
from mambalade.tokens import AccessPathToken,ImmutableToken,NativeToken,ObjectToken,Token,TypeToken,UnknownToken
from mambalade.vars import ConstraintVar,FilterInputVar,MapInputVar,MaxElementsVar,NamespaceVar,PropVar,SeqIndexVar
from.core import Object,object_getattribute,type_getattribute
from.helpers import NativeType,native_function,native_method,native_type,return_unknown,unsupported_native
from.module import ModuleToken
if TYPE_CHECKING:from mambalade.operations import Operations;from.core_tokens import NativeFunctionToken
logger=logging.getLogger(__name__)
@native_function('identity_decorator',supports_kwargs=True)
def identity_decorator(op,d):
	if(A:=d.args.args)and isinstance(A[0],Token|ConstraintVar):op.return_value(d,A[0])
@native_function('strict_identity_decorator',spec='lambda func, /: 1')
def strict_identity_decorator(op,d):
	if(A:=d.args.args)and isinstance(A[0],Token|ConstraintVar):op.return_value(d,A[0])
@native_function('noop',supports_kwargs=True)
def noop(_op,_d):0
builtin_functions={}
def register(t):builtin_functions[t.kind.name]=t;return t
@register
@native_function('id',spec=_D)
def id_(op,d):op.a.register_native_call(d.caller,d.callnode.node,id_.kind)
@register
@native_function('print',spec="lambda *objects, sep=' ', end='\\n', file=None, flush=False: 0")
def print_(op,d):op.a.register_native_call(d.caller,d.callnode.node,print_.kind)
@register
@native_function('super',spec='lambda typ=None, obj=None: 0')
def super_(op,d):
	A=op;A.a.register_native_call(d.caller,d.callnode.node,super_.kind);C=d.args
	if len(C.args)>=2:
		D=C.args[1]
		if not isinstance(D,ConstraintVar|Token):logger.debug('super() called with non-object argument');return
	else:
		if C.unpack_iter is not _A:A.a.warn_unsupported(d.callnode,'super() with iterable unpacking')
		if not isinstance((B:=d.caller),NodeSource)or not isinstance(B.namespace.node,FunctionNode):A.a.warn_unsupported(d.callnode,'super() called without arguments in a non-function context');return
		E=B.namespace.node.args;F=E.posonlyargs+E.args
		if not F:A.a.warn_unsupported(d.callnode,'super() called without arguments in a function without positional parameters');return
		D=NamespaceVar(B.namespace.node,B.context,F[0].arg)
	A.return_value(d,D)
@register
@native_function('len',spec=_D)
def len_(op,d):op.a.register_native_call(d.caller,d.callnode.node,len_.kind)
@register
@native_function('map',spec='lambda func, /, *iterables: 1')
def map_(op,d):
	A=op;from.iterator import IteratorToken as G;A.a.register_native_call(d.caller,d.callnode.node,map_.kind)
	if d.args.unpack_iter is not _A:A.a.warn_unsupported(d.callnode,'builtin.map with iterable unpacking')
	B,*C=d.args.args
	if not isinstance(B,Token|ConstraintVar):logger.debug('Ignoring builtin.map for non-object func %s',B);return
	if not C:logger.debug('Ignoring builtin.map without iterables');return
	vars=[]
	for(D,E)in enumerate(C):
		if not isinstance(E,Token|ConstraintVar):vars.append(_A);continue
		vars.append((H:=MapInputVar(d.callnode.node,d.context,D)));I=replace(d,res=H,parent=ListenerKey(Listener.NATIVE_MAP_INPUT,number=D,parent=d.parent));A.unpack_iterable_into(E,I)
	F=MapInputVar(d.callnode.node,d.context,-1);A.return_value(d,G(d.callnode,F));A.invoke_object(B,replace(d,args=AbstractArgs.seq(*vars),res=F,parent=ListenerKey(Listener.NATIVE_MAP_CALL,parent=d.parent)))
@register
@native_function('filter',spec='lambda func_or_none, iterable, /: 0')
def filter_(op,d):
	from.iterator import IteratorToken as E
	if d.args.unpack_iter is not _A:op.a.warn_unsupported(d.callnode,'builtin.filter with iterable unpacking')
	if len(d.args.args)==2:
		B,C=d.args.args;D=ListenerKey(Listener.NATIVE_FILTER,parent=d.parent)
		if isinstance(C,Token|ConstraintVar):A=FilterInputVar(d.callnode.node,d.context);op.return_value(d,E(d.callnode,A));op.unpack_iterable_into(C,replace(d,res=A,parent=D))
		else:A=_A
		if isinstance(B,Token|ConstraintVar):op.invoke_object(B,replace(d,args=AbstractArgs.seq(A),res=_A,parent=D))
@register
@native_function('max',spec='lambda *args, default=None, key=None: 0')
def max_(op,d):
	A=op;D,B=d,d.args
	for(E,C)in B.kwargs or():
		if E=='default':
			if isinstance(C,Token|ConstraintVar):A.return_value(d,C)
		elif E=='key':
			if isinstance(C,Token|ConstraintVar):F=MaxElementsVar(d.callnode.node,d.context);A.return_value(d,F);H=ListenerKey(Listener.NATIVE_MAX_KEY,parent=d.parent);A.invoke_object(C,replace(d,args=AbstractArgs.seq(F),res=_A,parent=H));D=replace(d,args=AbstractArgs.empty,res=F,parent=ListenerKey(Listener.NATIVE_MAX,parent=d.parent))
		else:assert E is _A;A.a.warn_unsupported(d.callnode,'builtin.max with mapping unpacking')
	if B.unpack_iter is _A and len(B.args)==1:
		G=B.args[0]
		if not isinstance(G,Token|ConstraintVar):logger.debug('Ignoring max() on non-object target %s',G);return
		A.unpack_iterable_into(G,D)
	else:
		for C in B.args:
			if isinstance(C,Token|ConstraintVar):A.return_value(D,C)
		if B.unpack_iter is not _A:A.unpack_iterable_into(B.unpack_iter,D)
builtin_functions['min']=max_
@register
@native_function('range',spec='lambda start, stop=None, step=1, /: 0')
def range_(op,d):op.a.register_native_call(d.caller,d.callnode.node,range_.kind)
@register
@native_function('sorted',spec='lambda iterable, /, *, key=None, reverse=False: 1')
def sorted_(op,d):from.import List as A;B=A.new_instance(op,d);op.return_value(d,B);C=ListenerKey(Listener.NATIVE_SORTED,parent=d.parent);A.call_slot('__init__',op,replace(d,args=AbstractArgs.seq(B,d.args.args[0]),res=_A,parent=C));A.call_slot('sort',op,replace(d,args=d.args.shift().prepend(B),res=_A,parent=d.parent))
@register
@native_function('reversed',spec='lambda sequence, /: 1')
def reversed(op,d):
	A=d.args.args[0]
	if not isinstance(A,Token|ConstraintVar):logger.debug(_B,A);return
	B=ListenerKey(Listener.NATIVE_REVERSED,parent=d.parent);op.invoke_special_method(A,'__reversed__',replace(d,args=AbstractArgs.empty,parent=B));native_iter.impl(op,d)
@register
@native_function('enumerate',spec='lambda iterable, start=0, /: 0')
def enumerate_(op,d):
	A=op;from.import Tuple;from.iterator import IteratorToken as E
	if d.args.unpack_iter is not _A:A.a.warn_unsupported(d.callnode,'builtin.enumerate with iterable unpacking')
	B=d.args.args[0]if d.args.args else _A
	for(C,F)in d.args.kwargs or():
		if C=='iterable':B=F
		elif C is _A:A.a.warn_unsupported(d.callnode,'builtin.enumerate with mapping unpacking')
	if isinstance(B,Token|ConstraintVar):D=Tuple.new_instance(A,d);A.return_value(d,E(d.callnode,D));G=ListenerKey(Listener.NATIVE_ENUMERATE,parent=d.parent);A.unpack_iterable_into(B,replace(d,args=AbstractArgs.empty,res=SeqIndexVar(D,1),parent=G))
@register
@native_function('zip',spec='lambda *iterables, strict=False: 0')
def zip_(op,d):
	from.import Tuple;from.iterator import IteratorToken as D
	if d.args.unpack_iter is not _A:op.a.warn_unsupported(d.callnode,'builtin.zip with iterable unpacking')
	A=Tuple.new_instance(op,d);op.return_value(d,D(d.callnode,A))
	for(B,C)in enumerate(d.args.args):
		if isinstance(C,Token|ConstraintVar):op.unpack_iterable_into(C,replace(d,res=SeqIndexVar(A,B),parent=ListenerKey(Listener.NATIVE_ZIP,number=B,parent=d.parent)))
@register
@native_function('iter',spec='lambda obj, sentinel=None, /: 1')
def native_iter(op,d):
	B=d.args;A,*D=B.args
	if not isinstance(A,Token|ConstraintVar):logger.debug(_B,A);return
	if B.unpack_iter is not _A:op.a.warn_unsupported(d.callnode,'Iterable unpacking in iter')
	if B.num_definite_pos_args==1:C=ListenerKey(Listener.NATIVE_ITER,parent=d.parent);op.invoke_special_method(A,'__iter__',replace(d,args=AbstractArgs.empty,parent=C))
	else:op.a.warn_unsupported(d.callnode,'iter with sentinel');C=ListenerKey(Listener.NATIVE_ITER_SENTINEL,parent=d.parent);op.invoke_object(A,replace(d,args=AbstractArgs.empty,res=_A,parent=C))
@register
@native_function('next',spec='lambda iterator, default=None, /: 1')
def native_next(op,d):
	A=d.args
	if A.unpack_iter is not _A:op.a.warn_unsupported(d.callnode,'Iterable unpacking in next')
	if len(A.args)==2 and isinstance((C:=A.args[1]),Token|ConstraintVar):op.return_value(d,C)
	if not isinstance((B:=A.args[0]),Token|ConstraintVar):logger.debug(_B,B);return
	D=ListenerKey(Listener.NATIVE_NEXT,parent=d.parent);op.invoke_special_method(B,'__next__',replace(d,args=AbstractArgs.empty,parent=D))
@register
@native_function('setattr',spec='lambda obj, name, value, /: 3')
def native_setattr(op,d):
	A,B,C=d.args.args
	if not isinstance(A,Token|ConstraintVar):logger.debug(_B,A);return
	D=ListenerKey(Listener.NATIVE_SETATTR,parent=d.parent);E=replace(d,args=AbstractArgs.seq(B,C),res=_A,parent=D);op.invoke_special_method(A,'__setattr__',E)
@register
@native_function('getattr',spec='lambda obj, name, default=None, /: 2')
def native_getattr(op,d):
	I='__getattr__';H='__getattribute__';A=op;C=d.args
	if C.unpack_iter is not _A:A.a.warn_unsupported(d.callnode,'Iterable unpacking in getattr')
	D,B=C.args[:2]
	if not isinstance(D,Token|ConstraintVar):logger.debug(_B,D);return
	if len(C.args)==3 and isinstance((J:=C.args[2]),Token|ConstraintVar):A.return_value(d,J)
	E=AbstractArgs.seq(B)
	def F(t):B=ListenerKey(Listener.NATIVE_GETATTR,number=1,parent=d.parent);A.invoke_special_method(t,H,replace(d,args=E,parent=B));C=ListenerKey(Listener.NATIVE_GETATTR,number=2,parent=d.parent);A.invoke_special_method(t,I,replace(d,args=E,res=_A,parent=C))
	if not isinstance(B,str):return F(D)
	def K(t):
		match t:
			case UnknownToken():A.return_value(d,t);return
			case AccessPathToken(J):C=ReadAccessPath(B);A.a.access_paths_manager.add_read_access_path(C,J,d.caller);A.return_value(d,AccessPathToken(C));return
			case _:assert_type(t,ObjectToken)
		match lookup_attr_mro(t.typ,H):
			case[NativeToken(Native('object.__getattribute__'|'type.__getattribute__'as K))]:
				if K.startswith('object'):D=object_getattribute(A,d,t,B)
				elif isinstance(t,TypeToken):D=type_getattribute(A,d,t,B)
				else:logger.debug('Discarding invalid call to type.__getattribute__ with non-type object: %s',t);return
				if not D and B!='__dict__':A.invoke_special_method(t,I,replace(d,args=E,res=_A,parent=G))
			case _:F(t)
	G=ListenerKey(Listener.NATIVE_GETATTR,parent=d.parent);A.forall_constraint_uncached(D,G,K)
@register
@native_function('__import__',spec='lambda name, globals=None, locals=None, fromlist=(), level=0, /: 1')
def import_(op,d):
	A=op;B=d.args
	if B.kwargs:A.a.warn_unsupported(d.callnode,'__import__ with keyword arguments');return
	C=B.args[0]
	if not isinstance(C,str):A.a.warn_unsupported(d.callnode,'__import__ with non-constant module name');return
	if B.num_definite_pos_args>=4:A.a.warn_unsupported(d.callnode,'__import__ with more than 3 arguments (fromlist is not supported)');return
	if B.num_definite_pos_args>=5:A.a.warn_unsupported(d.callnode,'__import__ with more than 4 arguments (level is not supported)');return
	E,D=A.absolute_import(ModuleIdentifier(C),_A,d.callnode.node,d.caller);A.return_value(d,E)
	if D is not _A:A.return_value(d,D)
@native_type(Object,tname='globals()',unsupported_methods='__iter__ keys values items pop'.split())
class Globals(NativeType):
	__new__=noop
	@native_method(_C,spec='lambda self, key, /: 2')
	@staticmethod
	def getitem(op,d):
		A,B=d.args.args
		if not isinstance(A,ImmutableToken)or A.typ is not Globals:logger.debug('Ignoring globals().__getitem__ on non-globals object %s',A);return
		assert isinstance(A.site,ModuleToken)
		if not isinstance(B,str):op.a.warn_unsupported(d.callnode,'Access to globals() with non-constant key');return
		op.return_value(d,PropVar(A.site,B))
	@native_method(_E,spec='lambda self, key, value, /: 3')
	@staticmethod
	def setitem(op,d):
		A,C,B=d.args.args
		if not isinstance(A,ImmutableToken)or A.typ is not Globals:logger.debug('Ignoring globals().__setitem__ on non-globals object %s',A);return
		assert isinstance(A.site,ModuleToken)
		if not isinstance(B,Token|ConstraintVar):return
		if isinstance(C,str):op.inclusion_constraint(B,PropVar(A.site,C))
		else:op.a.warn_unsupported(d.callnode,'Assignment to globals() with non-constant key');op.register_escaping(B,d)
	@native_method('get',spec=_F)
	@staticmethod
	def get(op,d):
		A=d.args;Globals.call_slot(_C,op,replace(d,args=AbstractArgs.seq(*A.args[:2])))
		if len(A.args)==3 and isinstance((B:=A.args[2]),Token|ConstraintVar):op.return_value(d,B)
	@native_method('setdefault',spec=_F)
	@staticmethod
	def setdefault(op,d):
		A=d.args.args;B,C=A[:2];Globals.call_slot(_C,op,replace(d,args=AbstractArgs.seq(B,C)))
		if len(A)==3:Globals.call_slot(_E,op,d)
@register
@native_function('globals',spec=_G)
def globals_(op,d):op.return_value(d,ImmutableToken(ModuleToken(source_module(d.caller)),Globals))
@register
@native_function('locals',spec=_G)
def locals_(op,d):
	match d.caller:
		case str():globals_.impl(op,d)
		case _:op.a.warn_unsupported(d.callnode,'builtin.locals()');op.return_value(d,UnknownToken())
builtin_functions.update({A:unsupported_native(f"builtin.{A}",return_unknown)for A in'\nanext aiter\ndelattr\neval exec compile\nvars'.split()})