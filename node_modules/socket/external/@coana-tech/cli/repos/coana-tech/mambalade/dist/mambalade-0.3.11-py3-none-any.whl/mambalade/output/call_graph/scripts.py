from __future__ import annotations
_C='Collapse contexts'
_B='--no-contexts'
_A='store_true'
import argparse
from pathlib import Path
from mambalade import graph
from.compare import compare_call_graphs,explode_targets
from.io import load_from_file
def diff_cgs():
	A=argparse.ArgumentParser(description='Explode two CGs and compare them');A.add_argument(_B,'-n',action=_A,help=_C);A.add_argument('cg1',type=Path,help='Path to the 1st CG file');A.add_argument('cg2',type=Path,help='Path to the 2nd CG file');B=A.parse_args()
	with B.cg1.open()as C,B.cg2.open()as D:E=load_from_file(C);F=load_from_file(D)
	print(compare_call_graphs(E,F,no_contexts=B.no_contexts).report(include_extra=True))
def vis_cg():
	D=argparse.ArgumentParser(description='Transform a CG into text or dot format and print it to stdout');D.add_argument(_B,'-n',action=_A,help=_C);D.add_argument('--dot',action=_A,help='Output in dot format');D.add_argument('--backwards-filter','-b',help='Only show edges that go to a target containing this string');D.add_argument('--forwards-filter','-f',help='Only show edges that go from a target containing this string');D.add_argument('cg',type=Path,help='Path to the CG file');B=D.parse_args()
	with B.cg.open()as M:H=load_from_file(M)
	E=explode_targets(H,max_target_len=5-B.no_contexts);A={B:A for(A,B)in enumerate(E)};C={(A[E[B]],A[E[C]])for(B,C)in H['edges']};I=len(A)
	def J(target,adj):D=target;nonlocal A,C;E=[B for(A,B)in A.items()if D in A];assert E,f"No targets contain '{D}'";B=graph.transitive_closure(adj.__getitem__,E);A={C:A for(C,A)in A.items()if A in B};C={(A,C)for(A,C)in C if A in B and C in B}
	if B.backwards_filter is not None:
		K=[[]for A in range(I)]
		for(F,G)in C:K[G].append(F)
		J(B.backwards_filter,K)
	if B.forwards_filter is not None:
		L=[[]for A in range(I)]
		for(F,G)in C:L[F].append(G)
		J(B.forwards_filter,L)
	if B.dot:
		print('digraph G {');print('rankdir=LR')
		for(N,O)in A.items():print(f'{O} [label="{N}"]')
		print('\n'.join(f"{A} -> {B}"for(A,B)in C));print('}')
	else:print('\n'.join(sorted(f"{E[A]} -> {E[B]}"for(A,B)in C)))