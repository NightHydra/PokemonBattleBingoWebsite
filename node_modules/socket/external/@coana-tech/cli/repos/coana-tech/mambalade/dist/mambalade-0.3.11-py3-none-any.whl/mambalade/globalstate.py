from __future__ import annotations
import ast,logging
from collections import defaultdict
from typing import TYPE_CHECKING,Final,Literal,Protocol,TypeAlias,TypeVar,cast,final
from.accesspathmanager import AccessPathsManager
from.diagnostics import Diagnostics
from.infos import CallEdge,CallEdgeKind,CallEdgeSource,ClassInfo,FunctionInfo,ModuleIdentifier,ModuleInfo,NamespaceNode,NamespaceNodeInfo,Native,NodeSource,QualifiedNode
from.options import Options
from.vars import ConstraintVar
if TYPE_CHECKING:
	from collections.abc import Callable;from.asthelpers import FunctionNode;from.contexts import Context;from.program import Program;from.tokens import Token;_K=TypeVar('_K',bound=ast.AST,contravariant=True);_V=TypeVar('_V',bound=NamespaceNodeInfo)
	class InfoMap(Protocol[_K,_V]):
		def __getitem__(A,B):...
		def __setitem__(A,B,C):...
logger=logging.getLogger(__name__)
EmptyVarError='tuple[QualifiedNode, str, Token | Callable[[], None]]'
@final
class GlobalState:
	def __init__(A,program,options=None):B=options;A.program=program;A.options=B if B is not None else Options();A.diagnostics=Diagnostics();A.access_paths_manager=AccessPathsManager();A.modules=dict[ModuleIdentifier,ModuleInfo]();A.worklist=[];A.unresolved_imports=set[ModuleIdentifier]();A.node_info=dict[NamespaceNode,NamespaceNodeInfo]();A.function_info=cast('dict[FunctionNode, FunctionInfo]',A.node_info);A.class_info=cast('dict[ast.ClassDef, ClassInfo]',A.node_info);A.call_edges=defaultdict[tuple[CallEdgeSource,ast.AST],set[CallEdge]](set);A.warnings_unsupported=defaultdict[QualifiedNode,set[str]](set);A.error_if_empty=defaultdict[ConstraintVar,list[EmptyVarError]](list)
	def __repr__(A):return f"{type(A).__name__}()"
	def warn_unsupported(B,node,message):
		A=message;C=B.warnings_unsupported[node]
		if A not in C:
			C.add(A)
			if B.options.warn_unsupported:logger.warning('Unsupported: %s at %s',A,node)
	def register_error_if_empty(A,var,*B):A.error_if_empty[var].append(B)
	def _register_edge(A,source,target):
		B=target
		if B not in(C:=A.call_edges[source]):C.add(B);A.diagnostics.call_edges+=1
	def register_import(A,caller,node,target):A._register_edge((caller,node),(CallEdgeKind.IMPORT,target))
	def register_native_call(A,caller,node,target):
		if A.options.native_edges:A._register_edge((caller,node),(CallEdgeKind.NATIVE,target))
	def register_call_edge(A,caller,node,callee,*,kind=CallEdgeKind.NORMAL):A._register_edge((caller,node),(kind,callee))