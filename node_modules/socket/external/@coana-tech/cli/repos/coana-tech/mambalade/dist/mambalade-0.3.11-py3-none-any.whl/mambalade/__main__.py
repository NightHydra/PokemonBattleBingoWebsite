from __future__ import annotations
_H='<seconds>'
_G='mambalade'
_F=False
_E='store_false'
_D=True
_C='<path>'
_B='store_true'
_A=None
import argparse,json,logging,os.path,sys,time
from dataclasses import dataclass
from datetime import timedelta
from functools import cache
from pathlib import Path
from.import distributions
from.api import Options,Program,analyze_program
from.files import transform_files_to_input
from.infos import ModuleIdentifier
from.options import ContextSensitivity,compute_tracked_modules
from.output import call_graph
from.output.call_graph.compare import compare_call_graphs,get_static_call_graph
from.output.diagnostics import dump_diagnostics
from.output.solver import dump_solution,solver_stats
from.output.vulns import dump_vulnerability_results
from.vulns import analyze_vulnerabilities,is_access_path_vuln
parser=argparse.ArgumentParser(prog=_G,description='Static call graph analysis for Python',formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('--log-level','-l',choices=('DEBUG','INFO','WARNING','ERROR','CRITICAL'),default='INFO',help='Set the log level')
parser.add_argument('--timeout',metavar=_H,type=float,help='Timeout in seconds')
parser.add_argument('--progress',metavar=_H,type=float,nargs='?',const=.5,help='Enable progress reports and optionally set interval')
parser.add_argument('--warn-unsupported',action=_B,help='Emit warnings for unsupported features')
parser.add_argument('--unsound-class-decorators',action=_E,dest='sound_class_decorators',help='Assume that class decorators always return the input class.\nThis can make a huge difference for precision, as user-defined decorators are not yet handled context-sensitively.')
parser.add_argument('--model-binop-data-flow',action=_B,help='Whether to model implicit calls to __add__ and __mul__ in binary operations.')
parser.add_argument('--model-mapping-unpacking',action=_B,help='Whether to model data flow for unpacked mappings at call sites.')
parser.add_argument('--exclude-modules',metavar='<module>',nargs='+',default=[],help='Exclude modules in distributions from the analysis')
parser.add_argument('--exclude-distributions',metavar='<distribution>',nargs='+',default=[],help='Exclude all modules in the specified distributions from the analysis. Names are case-insensitive.')
group=parser.add_mutually_exclusive_group()
group.add_argument('--context-sensitivity',choices=[A.name.lower()for A in ContextSensitivity],default=ContextSensitivity.OFF.name.lower(),help='\n'.join(f"{A.name.lower()}: {A.value}{" (default)"if A is ContextSensitivity.OFF else""}"for A in ContextSensitivity))
group.add_argument('--lazy-constraints',action='store_const',const='empty',dest='context_sensitivity',help="Delay constraint generation for library functions (sets context sensitivity to 'empty')")
parser.add_argument('--no-return-opt',action=_E,dest='return_constant_arg_optimization')
parser.add_argument('--no-rename-opt',action=_E,dest='variable_rename_optimization')
parser.add_argument('--output-callgraph','-j',metavar=_C,type=Path,help='Output the call graph to a JSON file')
parser.add_argument('--output-diagnostics',metavar=_C,type=Path,help='Output analysis diagnostics to a JSON file')
parser.add_argument('--output-vulnerabilities',metavar=_C,type=Path,help='Output vulnerability analysis results')
parser.add_argument('--output-tokens',metavar=_C,type=Path,help='Output the solution to a JSON file')
parser.add_argument('--soundness','-s',metavar=_C,type=Path,help='Path to a dynamic call graph for soundness checking')
parser.add_argument('--soundness-debug',action=_B,help='Print dynamic edges that will improve recall')
parser.add_argument('--vulnerabilities',metavar='<module:fqn>',nargs='+',default=[],help='Perform reachability analysis for the specified vulnerabilities')
parser.add_argument('--max-vulnerable-paths',type=int,default=10,help='Maximum number of vulnerable paths to compute')
parser.add_argument('--path',type=Path,nargs='+',default=[],help='Additional directories to add to the modeled sys.path')
parser.add_argument('--interactive-debugger',action=_B,help='Enable the post-analysis interactive debugger')
parser.add_argument('modules',metavar='<module or file>',nargs='+',help='The modules to analyze')
@dataclass(init=_F,slots=_D)
class Namespace:log_level:str;timeout:float|_A;progress:float|_A;warn_unsupported:bool;sound_class_decorators:bool;model_binop_data_flow:bool;model_mapping_unpacking:bool;exclude_modules:list[str];exclude_distributions:list[str];context_sensitivity:str;return_constant_arg_optimization:bool;variable_rename_optimization:bool;output_callgraph:Path|_A;output_diagnostics:Path|_A;output_vulnerabilities:Path|_A;output_tokens:Path|_A;soundness:Path|_A;soundness_debug:bool;vulnerabilities:list[str];max_vulnerable_paths:int;path:list[Path];interactive_debugger:bool;modules:list[str]
args=parser.parse_args(namespace=Namespace())
logging._srcfile=_A
logging.basicConfig(level=args.log_level,format='%(levelname)s: %(message)s')
logger=logging.getLogger(_G)
if args.vulnerabilities:
	for v in args.vulnerabilities:assert':'in v or is_access_path_vuln(v),f"Invalid vulnerability ID: {v}"
elif args.output_vulnerabilities is not _A:logger.error('--output-vulnerabilities without --vulnerabilities is useless')
if args.exclude_distributions:
	dist_to_pkgs=distributions.dist_to_pkgs(args.path)
	for dist in args.exclude_distributions:
		if(pkgs:=dist_to_pkgs.get(distributions.normalize(dist)))is _A:logger.error("Excluded distribution '%s' not found",dist);continue
		logger.info("Excluding packages from distribution '%s': %s",dist,', '.join(pkgs));args.exclude_modules.extend(pkgs)
imports=[]
files=[]
for module in args.modules:
	if(path:=Path(module)).is_file():files.append(path.resolve(strict=_D))
	else:imports.append(ModuleIdentifier(module))
sys_path=[A.resolve(strict=_D)for A in args.path]
if files:
	root=Path.cwd()
	if not all(A.is_relative_to(root)for A in files):
		root=Path(os.path.commonpath(files))
		if root.is_file():root=root.parent
	imps,spaths=transform_files_to_input(files,root);imports.extend(imps);sys_path[:0]=spaths
assert sys_path,'Empty sys.path!'
start=time.process_time()
s=analyze_program(Program(imports,sys_path),Options(timeout=_A if args.timeout is _A else timedelta(seconds=args.timeout),progress_interval=_A if args.progress is _A else timedelta(seconds=args.progress),warn_unsupported=args.warn_unsupported,sound_class_decorators=args.sound_class_decorators,excluded_modules=args.exclude_modules,native_edges=_F,context_sensitivity=ContextSensitivity[args.context_sensitivity.upper()],return_constant_arg_optimization=args.return_constant_arg_optimization,variable_rename_optimization=args.variable_rename_optimization,model_binop_data_flow=args.model_binop_data_flow,model_mapping_unpacking=args.model_mapping_unpacking,tracked_modules=compute_tracked_modules(args.vulnerabilities)))
a=s.global_state
vuln_res=analyze_vulnerabilities(a,args.vulnerabilities,max_paths=args.max_vulnerable_paths)if args.vulnerabilities else _A
elapsed=time.process_time()-start
print()
print(f"Modules: {len(a.modules):,}  ({len(a.unresolved_imports):,} unresolved)")
print(f"Code size: {a.diagnostics.code_size//2**10:,} KiB")
print('Solver stats:')
s_stats=solver_stats(s)
fmt_s_stats={B.replace('_',' ').title():f"{A:{".2%"if isinstance(A,float)else","}}"for(B,A)in s_stats.items()}
key_width=max(len(A)for A in fmt_s_stats)+1
value_width=max(len(A)for A in fmt_s_stats.values())
for(k,v)in fmt_s_stats.items():print(f"  {k+":":<{key_width}} {v:>{value_width}}")
print(f"Call edges: {sum(len(A)for A in a.call_edges.values()):,}")
print(f"Warnings for unsupported features: {sum(len(A)for A in a.warnings_unsupported.values()):,}")
print(f"Empty vars patched: {a.diagnostics.patched_empty_vars:,}")
print('Timings:')
timings=a.diagnostics.timings
width=max(len(A)for A in timings)+1
for(k,v)in a.diagnostics.timings.items():print(f"  {k+":":<{width}} {v.total_seconds():.3f}s")
@cache
def static_cg():return get_static_call_graph(a)
if args.output_callgraph is not _A:
	with args.output_callgraph.open('w')as f:json.dump(static_cg(),f)
	print(f"Call graph written to {args.output_callgraph}")
if args.output_tokens is not _A:dump_solution(s,args.output_tokens);print(f"Tokens written to {args.output_tokens}")
if args.output_diagnostics is not _A:
	with args.output_diagnostics.open('w')as f:dump_diagnostics(a,f,s_stats=s_stats,elapsed=elapsed)
	print(f"Diagnostics written to {args.output_diagnostics}")
if args.soundness is not _A:
	with args.soundness.open()as f:dyn_cg=call_graph.load_from_file(f)
	cmp=compare_call_graphs(dyn_cg,static_cg(),compare_reachability=_D);print();print(cmp.report(include_extra=_F))
	if args.soundness_debug and(imp:=[f"  {A}"for A in sorted(cmp.edges.missing)for(B,C)in[A.split(' -> ')]if B in cmp.reachable.common and C in cmp.reachable.missing]):print('\nDynamic edges that would improve recall:',*imp,sep='\n')
if args.vulnerabilities:
	assert vuln_res is not _A
	if sys.stdout.isatty():
		import re;site_packages_re=re.compile('^.*\\bsite-packages/');print('\nVulnerability analysis results:')
		for(v,r)in vuln_res.items():
			match r:
				case False,data:print(f"  {v}: unreachable ({data})")
				case _,data:
					print(f"  {v}: reachable")
					for(i,stack)in enumerate(data):
						print(f"    Path {i+1}/{len(data)}:");pkglen=max(len(A.package)for A in stack)+1;prev_pkg=''
						for node in stack:
							sloc=site_packages_re.sub('<lib>/',str(node.source_location))
							if node.package!=prev_pkg:prev_pkg=node.package;pkgs=f"{node.package}:"
							else:pkgs=''
							print(f"      {pkgs:<{pkglen}} {sloc} {node.confidence:.2%}")
	if args.output_vulnerabilities is not _A:
		with args.output_vulnerabilities.open('w')as f:dump_vulnerability_results(vuln_res,f)
if args.interactive_debugger:from mambalade.debugger.app import MambaladeDebugger;MambaladeDebugger(s).run()