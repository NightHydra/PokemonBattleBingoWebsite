from __future__ import annotations
import logging
from typing import TYPE_CHECKING
from mambalade.asthelpers import FunctionNode
from mambalade.contexts import EmptyContext
from mambalade.infos import FunctionInfo,ModuleKind,QualifiedNode,reachable_contexts
if TYPE_CHECKING:from mambalade.operations import Operations
logger=logging.getLogger(__name__)
def patch_unreachable_functions(op):
	B=op.a;E=EmptyContext();D=set[QualifiedNode[FunctionNode]]()
	for A in B.node_info.values():
		if not isinstance(A,FunctionInfo)or B.modules[A.node.module].kind!=ModuleKind.APP:continue
		if A.reachable_contexts or not A.visited:continue
		if(C:=A.parent_fun)is not None and(not C.reachable_contexts or C.node in D):continue
		logger.info('Patching unreachable function %s',A.node);D.add(A.node)
		for F in reachable_contexts(C):B.diagnostics.patched_unreachable_functions+=1;op.make_function_reachable(A,F,E,param_filled=frozenset(),has_kw_unpack=True)