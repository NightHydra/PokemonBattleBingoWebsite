from __future__ import annotations
_D='Any'
_C=False
_B=True
_A=None
from dataclasses import dataclass
from typing import TYPE_CHECKING,Any,Final,LiteralString,TypeAlias,cast,final
from typing_extensions import override
from mambalade.tokens import ImmutableToken,NativeToken,ObjectToken,TypeToken
if TYPE_CHECKING:from collections.abc import Callable;from mambalade.calls import CallData,ParameterList;from mambalade.infos import Native;from mambalade.operations import Operations;NativeFunctionImpl=Callable[[Operations,CallData],_A]
@final
@dataclass(slots=_B)
class NativeFunctionSpec:params:Final[ParameterList];required_known_pos:Final[int]=0
@final
class NativeFunctionToken(NativeToken):
	typ=cast(_D,_A)
	@override
	def __init__(self,kind,impl,spec):super().__init__(kind);self.impl=impl;self.spec=spec
	@override
	def _lookup_attr(self,attr):return _A,_C
@final
class ClassMethodToken(ObjectToken):
	immutable=_B;typ=cast(_D,_A)
	def __init__(A,fun):A.fun=fun
	@override
	def __str__(self):return f"ClassMethodToken({self.fun.kind})"
	@override
	def __eq__(B,A):return isinstance(A,ClassMethodToken)and B.fun==A.fun
	@override
	def __hash__(self):return hash((type(self),self.fun))
	@override
	def _lookup_attr(self,attr):
		if attr in('__func__','__wrapped__'):return self.fun,_B
		return _A,_C
@final
class NativeTypeToken(TypeToken,NativeToken):
	typ=cast(_D,_A);user_defined=_A
	@override
	def __init__(self,kind,mro,*,known_slots,unsupported=_C):A=self;super().__init__(kind);A.mro=A,*mro;A.known_slots=known_slots;A.unsupported=unsupported
	@override
	def _lookup_attr(self,attr):
		if(A:=self.known_slots.get(attr))is not _A:return A,_B
		return _A,_C
	def supports_instantiation(A):return not isinstance((B:=A.known_slots.get('__new__')),NativeFunctionToken)or B.kind.name!='noop'
	@override
	def new_instance(self,op,d):
		A=self;assert A.typ is not A,'Dynamic class creation'
		if A.unsupported:op.a.warn_unsupported(d.callnode,f"Instantiation of unmodeled native type '{A.kind.name}'")
		return ImmutableToken(d.callnode,A)
	def call_slot(B,name,op,d):A=B.known_slots[name];assert isinstance(A,NativeFunctionToken);A.impl(op,d)