from __future__ import annotations
from collections.abc import Callable,Hashable,Iterable,Set
from typing import TypeVar
_Node=TypeVar('_Node',bound=Hashable)
def transitive_closure(adj,initial):transitive_closure_inplace(adj,(A:=set(initial)));return A
def transitive_closure_inplace(adj,closure):
	A=closure;B=list(A)
	while B:
		if(D:=adj(B.pop())):
			for C in D:
				if C not in A:A.add(C);B.append(C)
def bfs(adj,initial):
	B=initial;C=set(B);D=list(B)
	for E in D:
		yield E
		if(F:=adj(E)):
			for A in F:
				if A not in C:C.add(A);D.append(A)