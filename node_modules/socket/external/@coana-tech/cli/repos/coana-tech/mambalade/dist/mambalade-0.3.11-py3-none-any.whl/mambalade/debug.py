from __future__ import annotations
_A=True
import ast,subprocess,sys
from collections import Counter,defaultdict
from collections.abc import Callable,Iterable,Mapping,Sized
from functools import cached_property
from typing import TYPE_CHECKING,TypeVar,final
from.infos import CallEdgeSource,CallEdgeTarget,ModuleIdentifier,QualifiedNode
from.listeners import ListenerKey
from.tokens import Token
from.vars import ConstraintVar
if TYPE_CHECKING:from.solver import Solver
class CTuple(tuple[object,Sized]):
	__slots__=()
	def __lt__(B,other):
		A=other
		if not isinstance(A,CTuple):return NotImplemented
		return len(B[1])<len(A[1])
	def __str__(A):return f"{A[0]} ({len(A[1])})"
	__repr__=__str__
N=TypeVar('N')
AN=TypeVar('AN',bound=ast.AST)
@final
class Debug:
	def __init__(A,solver):B=solver;A.solver=B;A.a=B.global_state;A.vars_to_tokens=B._tokens;A.subset_edges=B._subset_edges
	@cached_property
	def node_to_module(self):return{C:B for(B,A)in self.a.modules.items()if A.ast for C in ast.walk(A.ast)}
	def qfnode(A,n):return QualifiedNode(n,A.node_to_module[n])
	@cached_property
	def tokens_to_vars(self):
		A=defaultdict[Token,set[ConstraintVar]](set)
		for(B,C)in self.vars_to_tokens.items():
			for D in C:A[D].add(B)
		return A
	@cached_property
	def tokens_by_freq(self):return sorted(map(CTuple,self.tokens_to_vars.items()),reverse=_A)
	@cached_property
	def rev_subset_edges(self):
		A=defaultdict[ConstraintVar,set[ConstraintVar]](set)
		for(B,C)in self.subset_edges.items():
			for D in C:A[D].add(B)
		return A
	@cached_property
	def vars_by_tokens(self):return sorted(map(CTuple,self.vars_to_tokens.items()),reverse=_A)
	@cached_property
	def vars_by_edges(self):return sorted(map(CTuple,self.subset_edges.items()),reverse=_A)
	@cached_property
	def vars_by_rev_edges(self):return sorted(map(CTuple,self.rev_subset_edges.items()),reverse=_A)
	@cached_property
	def sites_by_callees(self):return sorted(map(CTuple,self.a.call_edges.items()),reverse=_A)
	@cached_property
	def callers(self):
		A=defaultdict[CallEdgeTarget,set[tuple[CallEdgeSource,ast.AST]]](set)
		for(B,C)in self.a.call_edges.items():
			for(E,D)in C:A[D].add(B)
		return A
	@cached_property
	def targets_by_callers(self):return sorted(map(CTuple,self.callers.items()),reverse=_A)
	@cached_property
	def listeners_by_processed_tokens(self):return sorted(map(CTuple,self.solver._listeners_processed.items()),reverse=_A)
	@cached_property
	def compressed_listeners_processed(self):
		B=Counter[ListenerKey]()
		for(A,C)in self.solver._listeners_processed.items():
			while A.parent is not None:A=A.parent
			B[A]+=len(C)
		return B
	@cached_property
	def listeners_by_rec_processed(self):return self.compressed_listeners_processed.most_common()
	@staticmethod
	def graphviz(rel,*J,max_size=128,label=str):
		B=['digraph G {','rankdir=LR; node [shape=box];'];E={}
		def I(n):return E.setdefault(n,len(E))
		F=list(J);C=set(F)
		for D in F:
			G=I(D);K=str(D).replace('"','\\"');B.append(f'{G} [label="{label(D)}", tooltip="{K}", xlabel="{G}"];')
			for A in rel.get(D,[]):
				if A not in C and len(C)<max_size:C.add(A);F.append(A)
				if A in C:B.append(f"{G} -> {I(A)};")
		B.append('}');H=subprocess.Popen(['xdot','-'],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=sys.stderr,text=_A);assert H.stdin is not None;H.stdin.write('\n'.join(B));H.stdin.close();return list(E)