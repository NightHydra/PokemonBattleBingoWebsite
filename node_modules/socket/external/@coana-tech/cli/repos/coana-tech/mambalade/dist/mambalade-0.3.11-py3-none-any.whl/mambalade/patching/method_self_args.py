from __future__ import annotations
import ast,logging
from typing import TYPE_CHECKING
from mambalade.asthelpers import expr_matches_module_attr
from mambalade.infos import ModuleKind,QualifiedNode,SynthProp
from mambalade.natives.core_tokens import NativeTypeToken
from mambalade.natives.functions import ClassMethod,FunctionToken
from mambalade.tokens import InstanceToken,ObjectToken,TypeToken
from mambalade.vars import ConstraintVar,NamespaceVar,PropVar
if TYPE_CHECKING:from mambalade.asthelpers import FunctionNode;from mambalade.solver import Solver
logger=logging.getLogger(__name__)
def patch_method_self_args(solver):
	A=solver;B=A.global_state
	with B.diagnostics.time('patching'):C=_do_patching(A)
	if C:
		logger.info('Re-propagating after patching self args')
		with B.diagnostics.time('propagation'):A.propagate()
def _known_decorator(decorator):A='final';return any(expr_matches_module_attr(decorator,A,B)for(A,B)in(('typing',A),('t',A),('dataclasses','dataclass')))
def _do_patching(solver):
	B=solver;D=B.global_state;L={}
	for O in B._tokens.values():
		for C in O:
			if isinstance(C,TypeToken)and(A:=C.user_defined)is not None and D.modules[A.module].kind==ModuleKind.APP:L.setdefault(A,set()).add(C)
	G=False
	def P(qfn,it):
		L='cls';K='self';nonlocal G;A=qfn.node;F=A.args.posonlyargs+A.args.args
		if not F or(C:=F[0].arg)not in(K,L):return
		if C==L and(not isinstance(A,ast.FunctionDef|ast.AsyncFunctionDef)or not any(isinstance(A,ast.Name)and A.id=='classmethod'for A in A.decorator_list)):return
		H=it.typ;E=D.function_info[A]
		if E.parent is None or E.parent.node!=H.user_defined:return
		for I in E.reachable_contexts:
			if B.empty_or_only_unknown((J:=NamespaceVar(A,I,C))):
				logger.info('Patching %s argument for %s @ %s',C,qfn,I);G=True
				if C==K:B.add_token_constraint(it,J);D.diagnostics.patched_self_args+=1
				else:B.add_token_constraint(H,J);D.diagnostics.patched_cls_args+=1
	for(A,H)in L.items():
		if any(not _known_decorator(A)for A in A.node.decorator_list):logger.info('Skipping patching of class %s with unknown decorators',A);continue
		if len(H)>=18:logger.warning('Skipping patching of class %s with %d tokens',A,len(H));continue
		Q=D.node_info[A.node].declarations
		for M in H:
			R=InstanceToken(M);I=[S for A in Q if isinstance((S:=M.lookup_attr(A)[0]),ConstraintVar)];E=set(I)
			for F in I:
				for C in B.get_tokens(F):
					match C:
						case FunctionToken(J):
							if J not in E:E.add(J);P(J,R)
						case ObjectToken(K):
							if K is ClassMethod:N=SynthProp.CLASSMETHOD_FUNCTION
							elif isinstance(K,NativeTypeToken)and K.kind.name.endswith('ContextManagerHelper'):N=SynthProp.CONTEXTMANAGER_FUNCTION
							else:continue
							if(F:=PropVar(C,N))not in E:I.append(F);E.add(F)
						case _:pass
	return G