from __future__ import annotations
_A='__main__'
import argparse,json,runpy,sys
from dataclasses import dataclass
from pathlib import Path
from mambalade.dynamic.profiler import Profiler
parser=argparse.ArgumentParser(prog='mambalade.dynamic',description='Dynamic call graph analysis for Python')
parser.add_argument('--output','-o',default='callgraph.json',help='Output file for callgraph')
parser.add_argument('--module-allowlist','-i',nargs='+',help='If this option is given only modules in the list will be included in the call graph. If a package is given all submodules will be included.')
parser.add_argument('--exclude-modules','-e',nargs='+',help='If this option is given the modules will be excluded from the call graph. If a package is given all submodules will be excluded.')
parser.add_argument('-m',action='store_true',help='Run library module as a script')
parser.add_argument('file',help='The script or module to run')
parser.add_argument('args',nargs=argparse.REMAINDER,help='Arguments to pass to the script')
@dataclass(init=False)
class Namespace:output:str;module_allowlist:list[str]|None;exclude_modules:list[str]|None;m:bool;file:str;args:list[str]
args=parser.parse_args(namespace=Namespace())
sys.argv[1:]=args.args
cg_path=Path(args.output).resolve()
assert cg_path.parent.is_dir(),f"Parent directory of {cg_path} does not exist"
profiler=Profiler(Path.cwd(),args.module_allowlist,args.exclude_modules)
try:
	with profiler:
		if args.m:runpy.run_module(args.file,run_name=_A,alter_sys=True)
		else:runpy.run_path(args.file,run_name=_A)
finally:
	print(f"Dumping callgraph to {cg_path}")
	with cg_path.open('w')as f:json.dump(profiler.get_call_graph(),f)