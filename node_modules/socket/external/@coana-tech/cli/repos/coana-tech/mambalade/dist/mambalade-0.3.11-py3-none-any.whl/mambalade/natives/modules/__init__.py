from __future__ import annotations
from._importer import NativeModuleImporter
__all__=['NativeModuleImporter']