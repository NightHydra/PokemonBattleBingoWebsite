from __future__ import annotations
_E='globals'
_D='builtins'
_C=True
_B=False
_A=None
import ast,functools,importlib.util,logging
from dataclasses import replace
from functools import partial
from typing import TYPE_CHECKING,Final,NamedTuple,TypeAlias,TypeVar,assert_type,cast,final
from typing_extensions import override
from mambalade.accesspathmanager import ImportAccessPath,ReadAccessPath
from mambalade.asthelpers import ComprehensionNode,FunctionNode,str_ast
from mambalade.calls import AbstractArg,AbstractArgs,CallData,ResultHandler
from mambalade.contexts import CompoundContext,Context,EmptyContext
from mambalade.infos import CallEdgeSource,FunctionInfo,ModuleIdentifier,ModuleInfo,ModuleKind,Native,NodeSource,QualifiedNode,SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.natives import BaseException as ABaseException
from mambalade.natives import Dict,Generator,List,Object,Set,Tuple
from mambalade.natives._namedtuple import make_typing_NamedTuple_subclass
from mambalade.natives.builtin_functions import identity_decorator,native_getattr,native_setattr
from mambalade.natives.core_tokens import NativeFunctionToken,NativeTypeToken
from mambalade.natives.dict import UnpackedDictToken
from mambalade.natives.functions import FunctionToken
from mambalade.natives.module import ModuleToken
from mambalade.natives.modules.typing import Generic
from mambalade.natives.sequences import EmptyTupleToken
from mambalade.options import ContextSensitivity
from mambalade.patching.empty_vars import resolve_empty_var_errors
from mambalade.token_utils import lookup_attr_mro,type_has_attr
from mambalade.tokens import AccessPathToken,ImmutableToken,InstanceToken,MROLinearizationError,ObjectToken,Token,TypeToken,UnknownToken,class_token
from mambalade.typing import checked_cast
from mambalade.util import TVL,is_dunder
from mambalade.vars import AttributeVar,ConstraintVar,DecoratorResultVar,DictKeyVar,ForIterElemVar,KwargsUnpackVar,NamespaceVar,NodeVar,PropVar,ReturnVar,SeqIndexVar,SubscriptVar
from.bindings import ResolvableNode,ResolvedNames,resolve_variable_bindings
from.namespace import Namespace,NamespaceVisitor
from.preanalysis import PreanalysisVisitor
from.rename import rename_to_single_assignment
from.transform import BoolEval,ConstantReturnRemover,TransformVisitor
if TYPE_CHECKING:from collections.abc import Callable,Iterator,Sequence;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
_SUPPORTED_DUNDERS=frozenset(f"__{A}__"for A in'\nnew init post_init del call getitem setitem init_subclass\niter next getattribute setattr copy deepcopy\nstr repr\nget set\nawait\nenter exit aenter aexit\nversion author copyright license maintainer email status credits\n'.split())
def analyze_module(info,op):
	D=info;A=op.a;E=A.options;I=D.name;B=D.ast;assert B is not _A
	with A.diagnostics.time('preanalysis'):
		J=BoolEval(D.kind);PreanalysisVisitor(I,A).visit(B);K,L,F=resolve_variable_bindings(B);TransformVisitor(J,A.diagnostics,F).visit(B)
		for(C,G)in K.items():
			if C not in(_D,_E)and G:
				H=A.node_info[C];assert not H.declarations;H.declarations=G
				if E.return_constant_arg_optimization and isinstance(C,FunctionNode):ConstantReturnRemover(checked_cast(FunctionInfo,H)).transform()
				if E.variable_rename_optimization and isinstance(C,ast.FunctionDef|ast.AsyncFunctionDef):rename_to_single_assignment(C,G,J,F,A.diagnostics)
		if E.context_sensitivity.need_freevars():
			for(M,N)in L.items():A.function_info[M].free_variables.update(N)
		if(O:={A for(B,C)in K.items()if B!=_D for A in C if is_dunder(A)}-_SUPPORTED_DUNDERS):A.warn_unsupported(QualifiedNode(B,I),f"Magic definitions: {", ".join(O)}")
	with A.diagnostics.time('constraint_setup'):AnalysisVisitor(D,F,op).setup_constraints(B)
_UNSUPPORTED_SPECIAL_ATTRIBUTES=frozenset(f"__{A}__"for A in'dict bases mro subclasses'.split())
_empty=object()
_AssignNode=ast.Assign|ast.AnnAssign|ast.NamedExpr|ast.For|ast.AsyncFor|ast.AsyncWith|ast.With|ast.comprehension
_Bases=tuple[TypeToken|NativeFunctionToken,...]
@final
class AnalysisVisitor(NamespaceVisitor):
	_builtin_module_token:Final=ModuleToken(ModuleIdentifier(_D));__slots__='context','module_info','module_name','module_token','op','options','resolved_names','solver'
	def __init__(A,info,resolved_names,op):B=info;super().__init__();B.visitor=A;A.resolved_names=resolved_names;A.op=op;A.solver=op.solver;A.options=op.a.options;A.module_info=B;A.module_name=B.name;A.module_token=ModuleToken(A.module_name);A.context=EmptyContext()
	def setup_constraints(A,node):
		match node:
			case ast.Module():A.context=EmptyContext();A.visit(node)
			case B,C:
				A.context=C;A._push_scope(B);A._args_inside(B.args)
				if isinstance(B,ast.Lambda):A.solver.add_subset_constraint(A.get_var(B.body),ReturnVar(A._qualify(B),C));A.visit(B.body)
				else:
					for D in B.body:A.visit(D)
				A._pop_scope()
	def eval(E,node,caller):
		C=caller;B=node
		match B:
			case ast.Constant(F)if type(F)in(int,str):return F
			case ast.Slice():return B
			case _:
				A=E.get_var(B)
				if not E.options.context_sensitivity.need_freevars()or not isinstance(A,NamespaceVar)or not isinstance((D:=A.context),CompoundContext)or not D.constant_params or(C:=cast('NodeSource',C)).context!=D or C.namespace.node!=A.node or(G:=next((C for(B,C)in D.constant_params if B==A.prop),_A))is _A:return A
				return G
	def _nvar(A,node):return NodeVar(node,A.context)
	def get_var(B,node,*,context=_A):
		D=node;C=context
		match D:
			case ast.Constant(A)if type(A)in(int,str,float,complex,bytes)or A is _A:return
			case ast.Slice():return
			case ast.Starred():raise AssertionError('Starred should not be evaluated')
			case ast.Name(ctx=E):assert isinstance(E,ast.Load);return B.resolve_name(D,context=C)
			case ast.Attribute(A,G,E):assert isinstance(E,ast.Load);return AttributeVar(F,G)if(F:=B.get_var(A,context=C))is not _A else _A
			case ast.Subscript(A,slice,H)if not isinstance(slice,ast.Slice):assert isinstance(H,ast.Load);I=cast('int | str',slice.value)if isinstance(slice,ast.Constant)and type(slice.value)in(int,str)else B.get_var(slice,context=C);return SubscriptVar(F,I)if(F:=B.get_var(A,context=C))is not _A else _A
			case _:return NodeVar(D,C or B.context)
	def _iter_scopes(C,scope=_A):
		A=scope
		if A is _A:A=C.scope
		if isinstance(A,ast.AST):
			B=C.op.a.node_info[A]
			while B is not _A:yield B.node.node;B=B.parent
		yield _E;yield _D
	def resolve_name(A,node,*,context=_A):
		match A.resolved_names[node]:
			case None:pass
			case'builtins',B,_:return PropVar(A._builtin_module_token,B)
			case'globals',B,_:return PropVar(A.module_token,B)
			case C,B,D:
				if not A.options.context_sensitivity.need_freevars():return NamespaceVar(C,A.context,B)
				if D is not _A:C=D;assert B in A.op.a.function_info[C].free_variables
				return NamespaceVar(C,context or A.context,B)
	def _get_var_patch_if_empty(A,node,message,patch):
		E=patch;D=message;C=node;B=A.get_var(C)
		if B is _A:B=A._nvar(C);resolve_empty_var_errors(A.solver,B,[(A._qualify(C),D,E)])
		elif A.solver.empty_or_only_unknown(B,include_unprocessed=_C):B,F=A._nvar(C),B;A.solver.add_subset_constraint(F,B);A.op.a.register_error_if_empty(B,A._qualify(C),D,E)
		return B
	def _cd(A,node,listener,args=AbstractArgs.empty,res=_empty,caller=_A):C=node;B=res;B=B if B is not _empty else A._nvar(C);return CallData(args,B,A._qualify(C),caller or A._caller(),ListenerKey(listener,(C,A.context)))
	def _decorator_chain(A,input,decorators,is_class=_B):
		B=decorators
		if not B:return input
		F=A._caller()
		def C(input,d):
			B=DecoratorResultVar(d,A.context);E=A._get_var_patch_if_empty(d,'Variable for decorator is empty',identity_decorator);C=ListenerKey(Listener.CALL_DECORATOR,(d,A.context));D=CallData(AbstractArgs.seq(input),B,A._qualify(d),F,C)
			if is_class and not A.options.sound_class_decorators:
				G=replace(D,res=_A,parent=ListenerKey(Listener.CALL_DECORATOR_NO_RES,parent=C))
				def H(t):
					if not isinstance(t,NativeFunctionToken|NativeTypeToken|UnknownToken|AccessPathToken):assert_type(t,ObjectToken);A.op.inclusion_constraint(input,B);C=G
					else:C=D
					A.op.invoke_object(t,C)
				A.op.forall_constraint_uncached(E,C,H)
			else:A.op.invoke_object(E,D)
			return B
		return functools.reduce(C,reversed(B),input)
	def _process_functions_immediately(A):return(B:=A.options.context_sensitivity)is ContextSensitivity.OFF or B is ContextSensitivity.EMPTY and A.module_info.kind is not ModuleKind.LIBRARY
	def _visit_fun(A,node):
		B=node;C=A.op.a.function_info[B];C.visited=_C;F=bool(C.free_variables)or any(B is not _A and A.get_var(B)is not _A for B in B.args.defaults+B.args.kw_defaults);D=FunctionToken(A._qualify(B),A.context if F else EmptyContext())
		if(E:=A._process_functions_immediately()):assert A.context is EmptyContext();C.reachable_contexts.add(A.context)
		if isinstance(B,ast.Lambda):
			A.solver.add_token_constraint(D,A._nvar(B))
			if E:A.solver.add_subset_constraint(A.get_var(B.body),ReturnVar(D.fun,A.context))
		else:A.op.inclusion_constraint(A._decorator_chain(D,B.decorator_list),A.resolve_name(B))
		return not E
	_N=TypeVar('_N',bound=ast.AST)
	def _qualify(A,node):return QualifiedNode(node,A.module_name)
	visit_FunctionDef=_visit_fun;visit_AsyncFunctionDef=_visit_fun;visit_Lambda=_visit_fun
	def _caller(A):
		for B in A._iter_scopes():
			if not isinstance(B,ComprehensionNode):
				if B==_E:return A.module_name
				else:assert B!=_D;return NodeSource(A._qualify(B),A.context)
		raise AssertionError('No caller found')
	def _super_attribute(A,node,res):
		D=res;B=node;E=A._caller()
		match(B.value,E):
			case ast.Call(func=ast.Name('super',ast.Load())as super,args=F,keywords=[]),NodeSource(QualifiedNode(ast.FunctionDef()|ast.AsyncFunctionDef()|ast.Lambda()as G)):H=G.args.posonlyargs+G.args.args
			case _:return _B
		match A.resolve_name(super):
			case PropVar(ModuleToken('builtins'),'super'):pass
			case _:return _B
		for C in A._iter_scopes():
			if isinstance(C,ast.ClassDef):break
		else:assert len(F)>=1;A.op.a.warn_unsupported(A._qualify(B.value),"Call to 'super' outside of class definition");return _B
		if not H:A.op.a.warn_unsupported(A._qualify(B.value),"Call to 'super' in function definition without named parameters");return _B
		I=H[0]
		match F:
			case[]|[ast.Name(C.name)]|[ast.Name(C.name),ast.Name(I.arg)]:pass
			case _:A.op.a.warn_unsupported(A._qualify(B.value),"Call to 'super' with unexpected arguments");return _B
		logger.debug('Successfully matched super call: %s',(L:=A._qualify(B)));J=B,A.context
		def K(t):
			match t:
				case ObjectToken():
					F=t if isinstance(t,TypeToken)else t.typ
					for(M,N)in enumerate(F.mro):
						if(O:=N.user_defined)is not _A and O.node==C:break
					else:logger.debug('super.__getattribute__ on %s does not have an MRO entry that matches %s',t,C.name);return
					G=ListenerKey(Listener.NATIVE_OBJECT__GETATTRIBUTE__,J,token=t);H=CallData(AbstractArgs.seq(),D,L,E,G)
					if isinstance(t,TypeToken):I=A.op.descr_handler(_A,t,H)
					else:I=A.op.descr_handler(t,t.typ,H)
					P=F.mro[M+1:]
					for Q in lookup_attr_mro(P,B.attr):A.solver.add_forall_constraint(Q,G,I)
				case UnknownToken():A.solver.add_token_constraint(t,D)
				case AccessPathToken(R):K=ReadAccessPath(B.attr);A.op.a.access_paths_manager.add_read_access_path(K,R,E);A.solver.add_token_constraint(AccessPathToken(K),D)
		if(M:=A.resolve_name(I))is not _A:A.solver.add_forall_constraint(M,ListenerKey(Listener.SUPER_GET_ATTR,J),K)
		return _C
	@override
	def visit_Attribute(self,node):
		B=self;A=node
		if not isinstance(A.ctx,ast.Load):return
		E=B._qualify(A)
		if A.attr in _UNSUPPORTED_SPECIAL_ATTRIBUTES:B.op.a.warn_unsupported(E,f"Access to special attribute: {A.attr}")
		if(F:=B.get_var(A.value))is _A:return
		C=AttributeVar(F,A.attr)
		if B._super_attribute(A,C):return
		D=B._caller();G=ListenerKey(Listener.GET_ATTR,(D.namespace.node,B.context),var=C)if isinstance(D,NodeSource)else ListenerKey(Listener.GET_ATTR,string=D,var=C);native_getattr.impl(B.op,CallData(AbstractArgs.seq(F,A.attr),C,E,D,G))
	@override
	def visit_Subscript(self,node):
		C=node;A=self
		if not isinstance(C.ctx,ast.Load):return
		if(G:=A.get_var(C.value))is not _A:
			D=A.get_var(C);B=A._caller();slice=A.eval(C.slice,B);E=ListenerKey(Listener.SUBSCRIPT,(B.namespace.node,A.context),var=D)if isinstance(B,NodeSource)else ListenerKey(Listener.SUBSCRIPT,string=B,var=D);F=A._qualify(C);H=CallData(AbstractArgs.seq(slice),D,F,B,ListenerKey(Listener.GET_ITEM,parent=E))
			def I(t):
				C='__getitem__'
				match t:
					case ObjectToken(G)if type_has_attr(G,C)is not TVL.FALSE:A.op.invoke_special_method(t,C,H)
					case TypeToken():
						if(I:=lookup_attr_mro(t,'__class_getitem__')):
							J=CallData(AbstractArgs.seq(t,slice),D,F,B,ListenerKey(Listener.CLASS_GETITEM,parent=E,token=t))
							for K in I:A.op.invoke_object(K,J)
					case ObjectToken()|AccessPathToken():pass
					case UnknownToken():A.solver.add_token_constraint(t,D)
			A.solver.add_forall_constraint(G,E,I)
	def visit_Call(A,node):
		B=node;D=A._caller();H=A.get_var(B.func);I=[];J=_A
		for(M,K)in enumerate(B.args):
			if isinstance(K,ast.Starred):J=A._iterable_from_exprs(B.args[M:],D);break
			I.append(A.eval(K,D))
		if H is _A:return
		E=[];F=[]
		for C in B.keywords:
			if C.arg is _A and A.options.model_mapping_unpacking:F.append(A.get_var(C.value))
			else:E.append((C.arg,A.eval(C.value,D)))
		if F:
			G=KwargsUnpackVar(B,A.context);E.append((_A,G))
			def N(t):
				match t:
					case UnknownToken():A.solver.add_token_constraint(t,G)
					case ObjectToken(C)if C is Dict:
						if not isinstance(t,UnpackedDictToken):t=UnpackedDictToken(t)
						A.solver.add_token_constraint(t,G)
					case ObjectToken(C):A.op.a.warn_unsupported(A._qualify(B),'Mapping unpacking with dict subclass'if Dict in C.mro else'Mapping unpacking with non-dict')
					case AccessPathToken():pass
			O=ListenerKey(Listener.CALL_KWARGS_UNPACK,(B,A.context))
			for L in F:
				if L is not _A:A.solver.add_forall_constraint(L,O,N)
		P=AbstractArgs(sum(not isinstance(A,ast.Starred)for A in B.args),tuple(I),J,E);A.op.invoke_object(H,A._cd(B,Listener.CALL_FUNCTION_CALLEE,P))
	def visit_Return(A,node):
		if node.value is not _A:
			B=A.scope;assert isinstance(B,ast.FunctionDef|ast.AsyncFunctionDef);C=A._qualify(B);A.solver.add_subset_constraint(A.get_var(node.value),ReturnVar(C,A.context))
			if A.op.a.function_info[B].generator:A.op.a.warn_unsupported(C,'Return in generator function')
	def _iterable_from_exprs(B,elts,caller):
		A=elts
		match A:
			case[ast.Starred(C)]:return B.get_var(C)
			case[]:raise AssertionError('Empty sequence of expressions')
			case _:return B._mk_seq_literal(A[0],Tuple,A,caller)
	def _handle_assign(A,caller,node,target,rhs,source):
		G=caller
		def H(target,rhs,source):
			K=source;E=target
			match E:
				case ast.Name(ctx=ast.Store()):A.op.inclusion_constraint(K,A.resolve_name(E))
				case ast.Attribute(L,Q,ctx=ast.Store()):
					if(M:=A.get_var(L))is not _A:native_setattr.impl(A.op,CallData(AbstractArgs.seq(M,Q,K),_A,A._qualify(node),G,parent=ListenerKey(Listener.SET_ATTR,(E,A.context))))
				case ast.Subscript(L,slice,ctx=ast.Store()):
					if(M:=A.get_var(L))is not _A:R=A.eval(slice,G);S=ListenerKey(Listener.SET_ITEM,(E,A.context));A.op.invoke_special_method(M,'__setitem__',CallData(AbstractArgs.seq(R,K),_A,A._qualify(node),G,S))
				case ast.Tuple(C,ctx=ast.Store())|ast.List(C,ctx=ast.Store()):
					match rhs:
						case ast.Tuple(D)|ast.List(D):
							assert isinstance(rhs.ctx,ast.Load)
							for(O,(B,F))in enumerate(zip(C,D,strict=_C)):
								if isinstance(B,ast.Starred)or isinstance(F,ast.Starred):break
								H(B,F,A.get_var(F))
							else:return
							C=C[O:];D=D[O:]
							while C and D:
								B,F=C[-1],D[-1]
								if isinstance(B,ast.Starred)or isinstance(F,ast.Starred):break
								H(C.pop(),D.pop(),A.get_var(F))
							else:raise AssertionError('One side of the assignment was exhausted???')
							N=A._iterable_from_exprs(D,G)
						case _:N=K
					I=_A;J=[]
					for B in C:
						match B:
							case ast.Starred():T=ImmutableToken(A._qualify(B),List);I=PropVar(T,SynthProp.SEQ_UNKNOWN);break
							case ast.Name(ctx=U):
								assert isinstance(U,ast.Store)
								if(V:=A.resolve_name(B))is not _A:J.append(V)
							case _:J.append(A._nvar(B))
					if N is not _A:A.op.unpack_iterable_into_vars(J,I,N,A._qualify(E),G,ListenerKey(Listener.ASSIGN_UNPACK,(E,A.context)))
					for(P,B)in enumerate(C):
						if isinstance(B,ast.Starred):assert I is not _A;H(B.value,_A,I.obj)
						else:H(B,_A,J[P]if P<len(J)else I)
				case _:raise AssertionError(f"Unexpected assignment target: {E!r}")
		H(target,rhs,source)
	def visit_Assign(B,node):
		A=node;C=B._caller();D=B.get_var(A.value)
		for E in A.targets:B._handle_assign(C,A,E,A.value,D)
	def visit_AnnAssign(B,node):
		A=node
		if A.value is not _A:B._handle_assign(B._caller(),A,A.target,A.value,B.get_var(A.value))
	def visit_NamedExpr(A,node):B=node;C=A.get_var(B.value);A._handle_assign(A._caller(),B,B.target,B.value,C);A.solver.add_subset_constraint(C,A._nvar(B))
	def visit_Dict(A,node):
		B=node;C=ImmutableToken((G:=A._qualify(B)),Dict);A.solver.add_token_constraint(C,A._nvar(B));H=A._caller();I,J=PropVar(C,SynthProp.DICT_KEYS),PropVar(C,SynthProp.DICT_VAL_UNKNOWN)
		for(E,K)in zip(B.keys,B.values,strict=_C):
			if E is _A:A.op.a.warn_unsupported(G,'Unpacking in dict literal');continue
			F=J;D=A.eval(E,H)
			if isinstance(D,str):F=DictKeyVar(C,D)
			elif isinstance(D,ConstraintVar):A.solver.add_subset_constraint(D,I)
			A.solver.add_subset_constraint(A.get_var(K),F)
	def _mk_seq_literal(A,site,typ,elts,caller):
		B=typ;assert B is Tuple or B is List;F=A._qualify(site);C=ImmutableToken(F,B);G=PropVar(C,SynthProp.SEQ_UNKNOWN);E=H=_C
		for(I,D)in enumerate(elts):
			if isinstance(D,ast.Starred):
				H=_B
				if(J:=A.get_var(D.value))is not _A:E=_B;K=ListenerKey(Listener.SEQ_UNPACK_ITER,(D,A.context),token=C);A.op.unpack_iterable_into(J,CallData(AbstractArgs.empty,G,F,caller,K))
			elif(L:=A.get_var(D))is not _A:E=_B;A.solver.add_subset_constraint(L,SeqIndexVar(C,I)if H and I<16 else G)
		if E and B is Tuple:return EmptyTupleToken()
		return C
	def visit_Tuple(A,node):
		B=node
		if not isinstance(B.ctx,ast.Load):return
		A.solver.add_token_constraint(A._mk_seq_literal(B,Tuple,B.elts,A._caller()),A._nvar(B))
	def visit_List(A,node):
		B=node
		if not isinstance(B.ctx,ast.Load):return
		A.solver.add_token_constraint(A._mk_seq_literal(B,List,B.elts,A._caller()),A._nvar(B))
	@override
	def visit_Set(self,node):
		B=node;A=self;C=ImmutableToken(A._qualify(B),Set);A.solver.add_token_constraint(C,A._nvar(B));D=[];F=PropVar(C,SynthProp.SET_VALUES)
		for E in B.elts:
			if isinstance(E,ast.Starred):
				if(G:=A.get_var(E.value))is not _A:D.append(G)
			else:A.solver.add_subset_constraint(A.get_var(E),F)
		if D:H=A._cd(B,Listener.SET_LITERAL,AbstractArgs.seq(C,*D));Set.call_slot('update',A.op,H)
	@override
	def visit_Import(self,node):
		A=self;D=A._caller()
		for B in node.names:C=A.resolve_name(B);E,F=A.op.absolute_import(ModuleIdentifier(B.name),B.asname,node,D);A.solver.add_token_constraint(E,C);A.op.inclusion_constraint(F,C)
	@override
	def visit_ImportFrom(self,node):
		O='Star-import from missing module';J='*';C=node;A=self;K=C.level*'.'+(C.module or'')
		try:L=ModuleIdentifier(importlib.util.resolve_name(K,package=A.module_info.spec.parent))
		except ImportError:
			A.op.a.diagnostics.failed_relative_imports+=1;logger.error("Relative import '%s' failed at %s",K,(P:=A._qualify(C)))
			for B in C.names:
				if B.name==J:A.op.a.warn_unsupported(P,O);continue
				A.solver.add_token_constraint(UnknownToken(),A.resolve_name(B))
			return
		F=A._caller();D,G=A.op.import_module(L,C,F)
		if C.names[0].name==J:
			assert A.scope==_E
			if isinstance(D,UnknownToken):A.op.a.warn_unsupported(A._qualify(C),O if G is _A else'Star-import from tracked module');return
			A.solver.add_forall_props_constraint(D,ListenerKey(Listener.IMPORT_STAR,(C,A.context)),lambda prop:A.solver.add_subset_constraint(PropVar(D,prop),PropVar(A.module_token,prop)))
		else:
			for B in C.names:
				assert B.name!=J;assert'.'not in B.name;E=A.resolve_name(B);H=f"{L}.{B.name}"
				if G is not _A and isinstance((M:=G.access_path),ImportAccessPath):H=f"{M.module_identifier}.{B.name}";N=ReadAccessPath(B.name);A.op.a.access_paths_manager.add_read_access_path(N,M,F);A.solver.add_token_constraint(AccessPathToken(N),E)
				if isinstance(D,ModuleToken):H=f"{D.id}.{B.name}";A.solver.add_subset_constraint(PropVar(D,B.name),E)
				I,Q=A.op.import_module(ModuleIdentifier(H),C,F,warn_if_missing=_B)
				if isinstance(I,ModuleToken)or D is I:A.solver.add_token_constraint(I,E)
				A.op.inclusion_constraint(Q,E)
	@override
	def visit_ClassDef(self,node):
		K='metaclass';B=node;A=self;C=A._qualify(B)
		if any(isinstance(A,ast.Starred)for A in B.bases):A.op.a.warn_unsupported(C,'Star-unpacking in class definition')
		if any(A.arg is _A for A in B.keywords):A.op.a.warn_unsupported(C,'Mapping unpacking in class definition')
		if any(A.arg==K for A in B.keywords):A.op.a.warn_unsupported(C,'Class definition with custom metaclass')
		F=A._nvar(B);A.op.inclusion_constraint(A._decorator_chain(F,B.decorator_list,is_class=_C),A.resolve_name(B));H=A._caller();I=B,(L:=A.context);J=A.op.a.class_info[B];M=J.declarations;N=[(B.arg,A.eval(B.value,H))for B in B.keywords if B.arg!=K]
		def D(bases=()):
			G=_resolve_bases(bases);logger.debug('Constructing class %s with bases %s',str_ast(B),G.bases)
			for K in G.bases:
				if isinstance(K,NativeTypeToken)and K.unsupported:A.op.a.warn_unsupported(C,f"Subclassing unmodeled native type '{K.kind.name}'")
			if G.named_tuple:
				D=make_typing_NamedTuple_subclass(A.solver,C,G.bases,J,L)
				if D is _A:return
			else:
				try:D=class_token(C,G.bases,J)
				except MROLinearizationError as O:A.op.a.diagnostics.failed_mro_linearizations+=1;logger.warning(O);return
				for E in M:A.solver.add_subset_constraint(NamespaceVar(B,L,E),PropVar(D,E))
			A.solver.add_token_constraint(D,F)
			if A.solver.num_tokens(F)==18:logger.warning('Many variants of class %s have been created',C)
			A.op.a.register_call_edge(H,B,NodeSource(C,EmptyContext()))
			if(P:=lookup_attr_mro(D.mro[1:],'__init_subclass__')):
				Q=CallData(AbstractArgs(1,(D,),_A,N),_A,C,H,ListenerKey(Listener.CLASSDEF_INIT_SUBCLASS,I,token=D))
				for R in P:A.op.invoke_object(R,Q)
			S=InstanceToken(D)
			for E in('__str__','__repr__','__del__','__hash__'):
				if E in M:A.op.invoke_special_method(S,E,CallData(AbstractArgs.empty,_A,C,H,ListenerKey(Listener.CLASSDEF_DUNDER_PATCH,I,string=E)))
		if not B.bases:D()
		else:
			A.op.a.register_error_if_empty(F,A._qualify(B),'Variable for class is empty',D);G=[A._get_var_patch_if_empty(B,'Variable for base class is empty',Object)for B in B.bases if not isinstance(B,ast.Starred)]
			def O(i,ts,t):
				match t:
					case TypeToken():
						for D in t.mro:
							if D.user_defined==C:logger.debug('Preventing circular inheritance for %s',str_ast(B));return
					case UnknownToken():A.solver.add_token_constraint(t,F);return
					case NativeFunctionToken(Native('typing.NamedTuple')):pass
					case _:
						if isinstance(t,ObjectToken):A.op.a.warn_unsupported(C,f"Base class token type: {type(t)}, discarding")
						else:assert_type(t,AccessPathToken)
						E(i+1,ts);return
				E(i+1,ts if t is Object else(*ts,t))
			def E(i,ts=()):
				if i==len(G):D(ts)
				else:B=G[i];A.solver.add_forall_constraint(B,ListenerKey(Listener.CLASSDEF_CONSTRUCT,I,tokens=ts,number=i),partial(O,i,ts))
			E(0)
	@override
	def visit_Raise(self,node):
		B=node;A=self
		if B.exc is not _A and(D:=A.get_var(B.exc))is not _A:
			C=A._cd(B,Listener.RAISE_EXCEPTION,res=_A)
			def E(t):
				if isinstance(t,TypeToken)and ABaseException in t.mro:A.op.invoke_object(t,C)
			A.solver.add_forall_constraint(D,C.parent,E)
	def _visit_for(A,node):
		B=node
		if isinstance(B,ast.comprehension):D,F=Listener.COMPREHENSION,B.is_async
		else:D,F=Listener.FOR_ITER,isinstance(B,ast.AsyncFor)
		H=A._caller();E=ForIterElemVar(B,A.context);A._handle_assign(H,B,B.target,_A,E)
		if(G:=A.get_var(B.iter))is not _A:
			if not F:A.op.unpack_iterable_into(G,A._cd(B,D,res=E))
			else:
				def I(agen):A.op.invoke_special_method(agen,'__anext__',K)
				def J(asend):A.op.awaitt(asend,L)
				C=A._cd(B,D,res=I);K=replace(C,res=J,parent=ListenerKey(Listener.ASYNC_FOR_NEXT,parent=C.parent));L=replace(C,res=E,parent=ListenerKey(Listener.ASYNC_FOR_AWAIT,parent=C.parent));A.op.invoke_special_method(G,'__aiter__',C)
	visit_AsyncFor=_visit_for;visit_For=_visit_for;visit_comprehension=_visit_for;with_exit_args:Final=AbstractArgs.seq(_A,_A,_A)
	def _visit_with(A,node):
		C=node;E=A._qualify(C);D=A._caller()
		for B in C.items:
			F=A._nvar(B);G=B,A.context
			if(I:=A.get_var(B.context_expr))is not _A:
				if isinstance(C,ast.With):J,K='__enter__',F;L,M='__exit__',_A
				else:
					def N(*,enter):B=enter;C=ListenerKey(Listener.AWAIT,G,number=int(B));H=CallData(AbstractArgs.empty,F if B else _A,E,D,C);return lambda r:A.op.awaitt(r,H)
					J,K='__aenter__',N(enter=_C);L,M='__aexit__',N(enter=_B)
				H=ListenerKey(Listener.WITH_ENTER,G);A.op.invoke_special_method(I,J,CallData(AbstractArgs.empty,K,E,D,H));H=ListenerKey(Listener.WITH_EXIT,G);A.op.invoke_special_method(I,L,CallData(A.with_exit_args,M,E,D,H))
			if B.optional_vars is not _A:A._handle_assign(D,C,B.optional_vars,_A,F)
	visit_With=_visit_with;visit_AsyncWith=_visit_with
	@override
	def visit_Yield(self,node):
		A=self
		if node.value is not _A and(C:=A.get_var(node.value))is not _A:B=A.scope;assert isinstance(B,FunctionNode);A.solver.add_subset_constraint(C,PropVar(ImmutableToken(A._qualify(B),Generator),SynthProp.GENERATOR_ELEMENT))
	@override
	def visit_YieldFrom(self,node):
		A=self
		if(C:=A.get_var(node.value))is not _A:B=A.scope;assert isinstance(B,FunctionNode);D=PropVar(ImmutableToken(A._qualify(B),Generator),SynthProp.GENERATOR_ELEMENT);A.op.unpack_iterable_into(C,A._cd(node,Listener.YIELD_FROM,res=D))
	@override
	def visit_ListComp(self,node):B=node;A=self;C=ImmutableToken(A._qualify(B),List);A.solver.add_token_constraint(C,A._nvar(B));A.solver.add_subset_constraint(A.get_var(B.elt),PropVar(C,SynthProp.SEQ_UNKNOWN))
	@override
	def visit_GeneratorExp(self,node):B=node;A=self;C=ImmutableToken(A._qualify(B),Generator);A.solver.add_token_constraint(C,A._nvar(B));A.solver.add_subset_constraint(A.get_var(B.elt),PropVar(C,SynthProp.GENERATOR_ELEMENT))
	@override
	def visit_DictComp(self,node):B=node;A=self;C=ImmutableToken(A._qualify(B),Dict);A.solver.add_token_constraint(C,A._nvar(B));A.solver.add_subset_constraint(A.get_var(B.key),PropVar(C,SynthProp.DICT_KEYS));A.solver.add_subset_constraint(A.get_var(B.value),PropVar(C,SynthProp.DICT_VAL_UNKNOWN))
	@override
	def visit_SetComp(self,node):B=node;A=self;C=ImmutableToken(A._qualify(B),Set);A.solver.add_token_constraint(C,A._nvar(B));A.solver.add_subset_constraint(A.get_var(B.elt),PropVar(C,SynthProp.SET_VALUES))
	@override
	def visit_BoolOp(self,node):
		A=self;B=A._nvar(node)
		for C in node.values:A.solver.add_subset_constraint(A.get_var(C),B)
	@override
	def visit_IfExp(self,node):B=node;A=self;A.solver.add_subset_constraint(A.get_var(B.body),(C:=A._nvar(B)));A.solver.add_subset_constraint(A.get_var(B.orelse),C)
	@override
	def visit_Await(self,node):
		A=self
		if(B:=A.get_var(node.value))is not _A:A.op.awaitt(B,A._cd(node,Listener.AWAIT))
	@override
	def visit_BinOp(self,node):
		B=node;A=self
		if not A.options.model_binop_data_flow:return
		match B.op:
			case ast.Add():C='__add__'
			case ast.Mult():C='__mul__'
			case _:return
		if(D:=A.get_var(B.left))is not _A:E=A.eval(B.right,(F:=A._caller()));A.op.invoke_special_method(D,C,A._cd(B,Listener.BIN_OP,AbstractArgs.seq(E),caller=F))
	@override
	def visit_Match(self,node):self.op.a.warn_unsupported(self._qualify(node),'Pattern matching')
class _ResolvedBases(NamedTuple):bases:tuple[TypeToken,...];named_tuple:bool
_default_bases=_ResolvedBases((Object,),_B)
def _resolve_bases(bases):
	B=bases
	if not B:return _default_bases
	C=E=D=_B;F=[]
	for A in reversed(B):
		match A:
			case TypeToken()if A is Generic and D:C=_C
			case TypeToken():D=D or Generic in A.mro;F.append(A)
			case NativeFunctionToken(G):assert G.name=='typing.NamedTuple';E=C=_C
	return _ResolvedBases(tuple(reversed(F))if C else cast('tuple[TypeToken, ...]',B),E)