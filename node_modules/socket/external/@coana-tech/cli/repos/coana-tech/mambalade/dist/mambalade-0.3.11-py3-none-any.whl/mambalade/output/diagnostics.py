from __future__ import annotations
import ast,datetime,json,platform,resource
from collections import Counter
from typing import TYPE_CHECKING
from mambalade.infos import FunctionInfo
if TYPE_CHECKING:import io;from mambalade.globalstate import GlobalState;from.solver import SolverStats
def _json_default(obj):
	match obj:
		case datetime.datetime():return obj.isoformat()
		case datetime.timedelta():return obj.total_seconds()
		case _:raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")
def dump_diagnostics(a,fp,*,elapsed,s_stats):
	unsupported_features=Counter(f for ws in a.warnings_unsupported.values()for f in ws if not f.startswith('Magic definitions'));functions=classes=analyzed_functions=analyzed_contexts=0
	for(n,info)in a.node_info.items():
		if isinstance(info,FunctionInfo):functions+=1;cs=info.reachable_contexts;analyzed_contexts+=len(cs);analyzed_functions+=bool(cs)
		elif isinstance(n,ast.ClassDef):classes+=1
	json.dump({'time':elapsed,'memory_usage':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'platform':{'human':platform.platform(),'machine':platform.machine(),'system':platform.system(),'python_branch':platform.python_branch(),'python_implementation':platform.python_implementation()},'diagnostics':vars(a.diagnostics),'functions':functions,'analyzed_functions':analyzed_functions,'analyzed_contexts':analyzed_contexts,'contexts_per_function':analyzed_contexts/max(1,analyzed_functions),'classes':classes,'warnings_unsupported':unsupported_features.total(),'unsupported_features':dict(unsupported_features.most_common()),'solver_stats':s_stats,'modules':{'resolved':sorted(a.modules),'unresolved':sorted(a.unresolved_imports)}},fp,indent=2,default=_json_default)