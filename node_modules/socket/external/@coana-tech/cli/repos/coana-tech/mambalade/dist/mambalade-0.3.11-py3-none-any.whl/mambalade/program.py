from __future__ import annotations
import os.path,sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING,Final
from.infos import ModuleIdentifier
if TYPE_CHECKING:from collections.abc import Sequence
_stdlib_path=Path(getattr(sys,'_stdlib_dir',None)or os.path.dirname(os.__file__)).resolve(strict=True)
@dataclass(frozen=True,slots=True)
class Program:
	initial_imports:Final[Sequence[ModuleIdentifier]];sys_path:Final[Sequence[Path]]
	@classmethod
	def empty(A):return A((),())
	@classmethod
	def from_file(A,path,sys_path=None):return A([ModuleIdentifier(path.stem)],[path.parent]+(sys_path or[]))