from __future__ import annotations
_I='contexts'
_H='<module>'
_G=False
_F='entries'
_E='target_entries'
_D='edges'
_C='targets'
_B='modules'
_A=None
import ast,contextlib,os.path
from dataclasses import dataclass
from typing import TYPE_CHECKING,Generic,Literal,Protocol,TypeVar,overload
from mambalade import graph
from mambalade.asthelpers import expr_matches_module_attr
from mambalade.infos import CallEdgeTarget,FunctionInfo,ModuleIdentifier,ModuleKind,Native,NodeSource,QualifiedNode
from mambalade.util import simple_cache
if TYPE_CHECKING:from collections.abc import Callable,Collection,Iterable,Sequence;from mambalade.globalstate import GlobalState;from.types import SerializedCallGraph,SerializedModule,SerializedTarget,V2SerializedCallGraph
def _is_fixture(fun):return fun is not _A and any(expr_matches_module_attr(A.func if isinstance(A,ast.Call)else A,'pytest','fixture')for A in fun.decorator_list)
class _RP(Protocol):
	def __call__(A,name,*,fun=_A):...
@simple_cache
def _test_root_predicate(module_name):
	C,C,A=module_name.rpartition('.')
	if A.startswith('test_')or A.endswith('_test'):
		def B(name,*,fun=_A):A,C,B=name.partition('_');return name.startswith(('test','setUp','tearDown'))or A in('setup','teardown')and B in('class','method','function')or _is_fixture(fun)
		return B
	elif A=='conftest':
		def B(name,*,fun=_A):return name.startswith('pytest_')or _is_fixture(fun)
		return B
def get_static_call_graph(a):
	C={};H=[]
	for(D,A)in a.modules.items():
		if A.kind in(ModuleKind.APP,ModuleKind.LIBRARY):H.append((D,M)if(L:=A.spec.origin)and not(M:=os.path.relpath(L,a.options.root_dir)).startswith('..')else(D,));C[D]=len(C)
	E={};F={}
	def B(t):
		match t:
			case Native():return
			case str(B):D=_H,1,0
			case QualifiedNode(A,B),H:
				if isinstance(A,ast.Lambda):G='<lambda>'
				else:G=A.name;A=A if not A.decorator_list else A.decorator_list[0]
				D=G,A.lineno,A.col_offset,E.setdefault(str(H),len(E))
		if(I:=C.get(B))is not _A:return F.setdefault((I,)+D,len(F))
	I=set[tuple[int,int]]()
	for((N,S),O)in a.call_edges.items():
		if(P:=B(N))is _A:continue
		I.update((P,Q)for(C,A)in O if(Q:=B(A))is not _A)
	J=[G for A in a.program.initial_imports if(G:=B(A))is not _A]
	for A in a.node_info.values():
		if isinstance(A,FunctionInfo)and not isinstance((K:=A.node.node),ast.Lambda)and A.reachable_contexts and a.modules[A.node.module].kind==ModuleKind.APP and(R:=_test_root_predicate(A.node.module))and R(K.name,fun=K):J.extend(G for C in A.reachable_contexts if(G:=B(NodeSource(A.node,C)))is not _A)
	return{_B:H,_C:list(F),_D:list(I),_E:J,_I:list(E)}
def filter_modules(cg,pred):
	A=cg;C=[];D=[-1]*len(A[_B])
	for(I,G)in enumerate(A[_B]):
		if pred(G[0]):D[I]=len(C);C.append(G)
	A[_B]=C
	if _F in A:A[_F]=[A for A in A[_F]if D[A]!=-1]
	E=A[_C];F=list(E[:0]);B=[-1]*len(E)
	for(J,H)in enumerate(E):
		if(K:=D[H[0]])!=-1:B[J]=len(F);F.append((K,)+H[1:])
	if _E in A:A[_E]=[L for A in A[_E]if(L:=B[A])!=-1]
	A[_D]=[M for(A,C)in A[_D]if-1 not in(M:=(B[A],B[C]))];A[_C]=F;return A
@dataclass
class Comp:
	missing:Collection[str];extra:Collection[str];common:Collection[str]
	def _report(A,include_extra):
		def B(a,b):return f"{a}/{b} ({a/b if b!=0 else 1:.2%})"
		C=len(A.missing)+len(A.common);yield f"Common: {B(len(A.common),C)}"
		if A.missing:D=len(A.missing);yield'';yield f"Missing: {B(D,C)}";yield from sorted(A.missing)
		if A.extra:
			yield'';yield f"Extra: {B(len(A.extra),len(A.extra)+len(A.common))}"
			if include_extra:yield from sorted(A.extra)
_CompOrNone=TypeVar('_CompOrNone',Comp,_A)
@dataclass
class CGComparison(Generic[_CompOrNone]):
	modules:Comp;edges:Comp;reachable:_CompOrNone
	def report(C,include_extra=_G):
		A=[]
		for B in(_B,_D,'reachable'):
			if not(D:=getattr(C,B)):continue
			A.append(f"{B.capitalize()}:");A.extend(f"\t{A}"for A in D._report(include_extra));A.append('')
		return'\n'.join(A)
def _max_target_len(cg):return max(len(A)for A in cg[_C])
def explode_targets(cg,max_target_len,modules=_A):
	C=max_target_len;B=modules;assert C>=2
	if B is _A:B=[A for(A,*B)in cg[_B]]
	D=cg.get(_I)
	def A(t):
		F,G,*A=t;A=A[:C-2];E=[B[F],G,*map(str,A[:2])]
		if len(A)==3:assert D is not _A;E.append(D[A[-1]])
		return':'.join(E)
	return[A(B)for B in cg[_C]]
@overload
def compare_call_graphs(a,b,*,compare_reachability,no_contexts=_G):...
@overload
def compare_call_graphs(a,b,*,no_contexts=_G):...
def compare_call_graphs(a,b,*,compare_reachability=_G,no_contexts=_G):
	D={}
	for N in a[_B]:
		if len(N)==2:
			O,P=N
			if len(O)>len(D.get(P,'')):D[P]=O
	E,F=([D.get(A[1],A[0])if len(A)==2 else A[0]for A in A[_B]]for A in(a,b));G=set(E)&set(F);Q=Comp(missing=set(E)-G,extra=set(F)-G,common=G);R=min(_max_target_len(a),_max_target_len(b),5-no_contexts);A=explode_targets(a,R,E);H=explode_targets(b,R,F);I={f"{A[B]} -> {A[C]}"for(B,C)in a[_D]};J={f"{H[A]} -> {H[B]}"for(A,B)in b[_D]};S=Comp(missing=I-J,extra=J-I,common=I&J)
	if not compare_reachability:return CGComparison(Q,S,_A)
	B=set[int]()
	if _F in b:
		K={A:[]for A in range(len(b[_B]))}
		for(L,(C,*W))in enumerate(b[_C]):K[C].append(L)
		for C in b[_F]:
			with contextlib.suppress(ValueError):B.add(next(A for A in K[C]if b[_C][A][1]==_H))
			if(U:=_test_root_predicate(b[_B][C][0])):B.update(A for A in K[C]if U(b[_C][A][1]))
	else:assert _E in b;B.update(b[_E])
	T=[set[int]()for A in range(len(b[_C]))]
	for(L,V)in b[_D]:T[L].add(V)
	graph.transitive_closure_inplace(T.__getitem__,B);M={H[A]for A in B};return CGComparison(Q,S,Comp(missing=set(A)-M,extra=M-set(A),common=set(A)&M))