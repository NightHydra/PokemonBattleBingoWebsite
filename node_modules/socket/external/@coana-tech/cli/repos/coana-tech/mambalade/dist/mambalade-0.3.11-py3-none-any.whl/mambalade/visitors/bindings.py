from __future__ import annotations
_E='builtins'
_D='globals'
_C=True
_B=False
_A=None
import ast,builtins,enum
from abc import ABC,abstractmethod
from collections.abc import Iterable,Mapping
from typing import Final,Literal,NamedTuple,TypeAlias,TypeGuard,cast,final
from typing_extensions import override
from mambalade.asthelpers import ComprehensionNode,FunctionNode
from mambalade.infos import NamespaceNode
from.namespace import Namespace,NamespaceVisitor,ScopeChain
ResolvableNode=ast.Name|ast.arg|ast.alias|ast.MatchAs|ast.MatchStar|ast.MatchMapping|ast.FunctionDef|ast.AsyncFunctionDef|ast.ClassDef|ast.ExceptHandler
class BindingMixin(ABC,ast.NodeVisitor):
	@abstractmethod
	def handle_binding(self,node,name):0
	@override
	def visit_Name(self,node):
		A=node
		if isinstance(A.ctx,(ast.Store,ast.Del)):self.handle_binding(A,A.id)
	@final
	def _visit_named(self,node):self.handle_binding(node,node.name)
	visit_ClassDef=_visit_named;visit_FunctionDef=_visit_named;visit_AsyncFunctionDef=_visit_named
	@override
	def visit_arg(self,node):self.handle_binding(node,node.arg)
	@override
	def visit_alias(self,node):
		A=node
		if A.asname is not _A:self.handle_binding(A,A.asname)
		elif A.name!='*':self.handle_binding(A,A.name.partition('.')[0])
	@final
	def _visit_maybe_named(self,node):
		A=node
		if A.name is not _A:self.handle_binding(A,A.name)
	visit_MatchAs=_visit_maybe_named;visit_MatchStar=_visit_maybe_named;visit_ExceptHandler=_visit_maybe_named
	@override
	def visit_MatchMapping(self,node):
		A=node
		if A.rest is not _A:self.handle_binding(A,A.rest)
@final
class DeclInfo(NamedTuple):jump_to_global:bool;constant:bool;captured:bool
Declarations=Mapping[Namespace,Mapping[str,DeclInfo]]
_global_decl=DeclInfo(_C,_B,_B)
_constant_local_decl=DeclInfo(_B,_C,_B)
_constant_free_decl=DeclInfo(_B,_C,_C)
_variable_local_decl=DeclInfo(_B,_B,_B)
_variable_free_decl=DeclInfo(_B,_B,_C)
@final
class DefVisitor(NamespaceVisitor,BindingMixin):
	__slots__='banned_names','declarations','delayed_resolves'
	def __init__(A):super().__init__();A.banned_names={};A.declarations={};A.delayed_resolves=[]
	@override
	def handle_binding(self,node,name):
		B=name;A=self;A.delayed_resolves.append((A.scopes,(node,B)));C=A.scope;assert C!=_E,'We should not declare names in the builtins namespace'
		if B in A.banned_names.get(C,()):
			if not isinstance(C,ComprehensionNode):return
			for C in A.scopes:
				if not isinstance(C,ComprehensionNode):break
			else:raise AssertionError('Name is banned in a comprehension, but no parent scope found')
			if B in A.banned_names.get(C,()):return
		D=A.declarations.setdefault(C,{})
		if(E:=D.get(B))is not _A:
			if E.jump_to_global:D=A.declarations[_D];E=D[B]
			if E.constant:D[B]=_variable_free_decl if E.captured else _variable_local_decl
		else:D[B]=_constant_local_decl
	@override
	def visit_Global(self,node):
		A=self;assert len(A.scopes)>=2;C=A.scope;D=A.declarations.setdefault(_D,{})
		for B in node.names:D.setdefault(B,_constant_local_decl)
		if C!=_D:
			E=A.declarations.setdefault(C,{})
			for B in node.names:F=E.setdefault(B,_global_decl);assert F is _global_decl
	@override
	def visit_Nonlocal(self,node):B=node;A=self;assert len(A.scopes)>2;A.delayed_resolves.append((A.scopes,B));C=A.scope;A.banned_names.setdefault(C,set()).update(B.names);D=A.declarations.get(C,());assert not any(A in D for A in B.names)
	@override
	def visit_NamedExpr(self,node):
		A=self;assert isinstance(node.target.ctx,ast.Store);C=node.target.id
		for B in A.scopes:
			if not isinstance(B,ComprehensionNode):break
			assert C not in A.declarations.get(B,());A.banned_names.setdefault(B,set()).add(C)
	@override
	def visit_Name(self,node):
		A=node;super().visit_Name(A)
		if isinstance(A.ctx,ast.Load):self.delayed_resolves.append((self.scopes,(A,A.id)))
_builtin_declarations=frozenset(dir(builtins))
def is_load(node):return isinstance(node,ast.Name)and isinstance(node.ctx,ast.Load)
def resolve_name(scopes,declarations,name):
	B=_A;C=_B
	for(D,A)in enumerate(scopes):
		if D>0 and isinstance(A,ast.ClassDef):continue
		if A==_E:
			if name in _builtin_declarations:return _E,_A,_B
		elif(E:=declarations.get(A))and(F:=E.get(name)):
			if A==_D or F.jump_to_global:return _D,_A,_B
			return A,B,C
		elif isinstance(A,FunctionNode)and B is _A:B=A;C=_C
		elif isinstance(A,ast.GeneratorExp):C=_C
	return _D,_A,_B
@final
class Free(enum.Flag):READ=enum.auto();WRITE=enum.auto()
@final
class ResolvedName(NamedTuple):
	ns:Namespace;name:str;containing_fn:FunctionNode|_A
	def is_free(A):return A.containing_fn is not _A
FreeVars=Mapping[FunctionNode,Mapping[str,tuple[Free,NamespaceNode]]]
ResolvedNames=dict[ResolvableNode,ResolvedName|_A]
def resolve_variable_bindings(mod):
	F=DefVisitor();F.visit(mod);assert len(F.scopes)==1;D=F.declarations;K={};L={}
	def M(scopes,res,name,fr):
		A=name
		def D(scope):
			B=scope
			if C is not _A:
				D=K.setdefault(C,{})
				if(E:=D.get(A))is _A:D[A]=fr,B
				else:assert B is E[1];D[A]=fr|E[0],B
		C=_A
		for B in scopes:
			if B is res:D(res);break
			elif isinstance(B,FunctionNode):D(B);C=B
		else:raise AssertionError(f"Name {A!r} was not resolved to a scope")
	for(G,C)in F.delayed_resolves:
		if isinstance(C,ast.Nonlocal):
			for A in C.names:
				H,N,I=resolve_name(G,D,A);assert H not in(_A,_E,_D);E=D[H];B=E[A];assert not B.jump_to_global;O=B.captured or I
				if B.constant or O!=B.captured:E[A]=_variable_free_decl if O else _variable_local_decl
				M(G,H,A,Free.WRITE)
		else:
			C,A=C;J,N,I=resolve_name(G,D,A);P=L[C]=ResolvedName(J,A,N)
			if I:
				E=D[J];B=E[A];assert not B.jump_to_global
				if not B.captured:E[A]=_constant_free_decl if B.constant else _variable_free_decl
				if is_load(C)and P.is_free():M(G,cast('NamespaceNode',J),A,Free.READ)
	return D,K,L