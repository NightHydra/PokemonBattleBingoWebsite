from __future__ import annotations
_B='lambda self, /: 1'
_A='update'
import logging
from dataclasses import replace
from typing import TYPE_CHECKING
from mambalade.calls import AbstractArgs,CallData
from mambalade.infos import SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.tokens import ObjectToken,Token
from mambalade.util import TVL
from mambalade.vars import ConstraintVar,PropVar
from.builtin_functions import noop
from.core import Object
from.helpers import NativeType,generic_class_getitem,native_method,native_type
from.iterator import IteratorToken
if TYPE_CHECKING:from mambalade.operations import Operations
logger=logging.getLogger(__name__)
@native_type(Object,unsupported_methods='intersection_update difference_update symmetric_difference_update'.split())
class Set(NativeType):
	__class_getitem__=generic_class_getitem
	@native_method('__init__',spec='lambda self, iterable=None, /: 1')
	@staticmethod
	def init(op,d):
		A,*B=d.args.args
		if not isinstance(A,ObjectToken)or Set not in A.typ.mro:logger.debug('Ignoring set.__init__ for non-set %s',A);return
		if B:Set.call_slot(_A,op,replace(d,args=AbstractArgs.seq(A,*B)))
		elif d.args.unpack_iter:op.a.warn_unsupported(d.callnode,'set.__init__ with iterable unpacking')
	@native_method('add',spec='lambda self, elem, /: 1')
	@staticmethod
	def add(op,d):
		from mambalade.token_utils import object_hashable as D;A,*B=d.args.args
		if not isinstance(A,ObjectToken)or Set not in A.typ.mro:logger.debug('Ignoring set.add for non-set %s',A);return
		if B:
			if isinstance((C:=B[0]),Token|ConstraintVar)and D(C)is not TVL.FALSE:op.inclusion_constraint(C,PropVar(A,SynthProp.SET_VALUES))
		elif d.args.unpack_iter:op.a.warn_unsupported(d.callnode,'set.add with iterable unpacking')
	@native_method('pop',spec=_B)
	@staticmethod
	def pop(op,d):
		if isinstance((A:=d.args.args[0]),ObjectToken)and Set in A.typ.mro:op.return_value(d,PropVar(A,SynthProp.SET_VALUES))
		else:logger.debug('Ignoring set.pop for non-set %s',A)
	@native_method('__iter__',spec=_B)
	@staticmethod
	def iter(op,d):
		if isinstance((A:=d.args.args[0]),ObjectToken)and Set in A.typ.mro:op.return_value(d,IteratorToken(A,PropVar(A,SynthProp.SET_VALUES)))
		else:logger.debug('Ignoring set.__iter__ for non-set %s',A)
	@native_method(_A,spec='lambda self, /, *others: 1')
	@staticmethod
	def update(op,d):
		from mambalade.token_utils import object_hashable as E;A,*B=d.args.args
		if not isinstance(A,ObjectToken)or Set not in A.typ.mro:logger.debug('Ignoring set.update for non-set %s',A);return
		if not B and not d.args.unpack_iter:return
		def F(elem):
			if E(elem)is not TVL.FALSE:op.inclusion_constraint(elem,G)
		G=PropVar(A,SynthProp.SET_VALUES);C=replace(d,res=F,parent=ListenerKey(Listener.NATIVE_SET_UPDATE,parent=d.parent))
		for D in B:
			if isinstance(D,Token|ConstraintVar):op.unpack_iterable_into(D,C)
		if(iter:=d.args.unpack_iter):
			def H(iterable):op.unpack_iterable_into(iterable,C)
			I=ListenerKey(Listener.NATIVE_SET_UPDATE_UNPACK,parent=d.parent);op.unpack_iterable_into(iter,replace(d,res=H,parent=I))
	clear=noop