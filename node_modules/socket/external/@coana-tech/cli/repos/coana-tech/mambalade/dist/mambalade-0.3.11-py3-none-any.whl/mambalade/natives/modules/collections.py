from __future__ import annotations
import logging
from dataclasses import replace
from typing import TYPE_CHECKING
from mambalade.calls import AbstractArgs,CallData
from mambalade.infos import Native
from mambalade.listeners import Listener,ListenerKey
from mambalade.natives import Dict,List,Object
from mambalade.natives._namedtuple import namedtuple
from mambalade.natives.core_tokens import NativeTypeToken
from mambalade.natives.dict import dict_setitem
from mambalade.natives.helpers import NativeType,generic_class_getitem,native_method,native_type
from mambalade.tokens import NativeToken,ObjectToken,Token
from mambalade.vars import ConstraintVar
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
@native_type(Dict,Object,tname='collections.defaultdict',unsupported_methods=('__missing__',))
class DefaultDict(NativeType):
	@native_method('__init__',spec='lambda self, default_factory=None, /, *args, **kwargs: 0')
	@staticmethod
	def init(op,d):
		B=d.args
		if B.unpack_iter:op.a.warn_unsupported(d.callnode,'Iterable unpacking in defaultdict.__init__')
		if B.num_definite_pos_args>2 or B.kwargs:op.a.warn_unsupported(d.callnode,'defaultdict.__init__ with initial data')
		if len(B.args)>=2:
			A,C=B.args[:2]
			if not isinstance(A,ObjectToken):logger.debug('Ignoring defaultdict.__init__ for non-constant token %s',A);return
			if DefaultDict not in A.typ.mro:logger.debug('Ignoring defaultdict.__init__ for non-defaultdict %s',A);return
			if isinstance(C,Token|ConstraintVar):
				def D(r):dict_setitem(op,A,None,r)
				E=ListenerKey(Listener.NATIVE_DEFAULTDICT__INIT__,token=A,parent=d.parent);op.invoke_object(C,replace(d,args=AbstractArgs.empty,res=D,parent=E))
model={'namedtuple':namedtuple,'defaultdict':DefaultDict}|{A:NativeTypeToken(Native(f"collections.{A}"),(*B,Object),known_slots={'__class_getitem__':generic_class_getitem}if not B else{},unsupported=True)for(A,B)in(('deque',()),('ChainMap',(Dict,)),('Counter',(Dict,)),('OrderedDict',(Dict,)),('UserDict',(Dict,)),('UserList',(List,)),('UserString',()))}