from __future__ import annotations
_A=None
import ast,importlib.abc,importlib.machinery,logging,os.path,platform,pprint,sys,traceback
from pathlib import Path
from typing import TYPE_CHECKING
from.globalstate import GlobalState
from.imports import Importer
from.infos import FunctionInfo,ModuleIdentifier,ModuleInfo,QualifiedNode
from.natives import ModuleToken
from.natives.dict import UnpackedDictToken
from.natives.modules import NativeModuleImporter
from.operations import Operations
from.options import MAMBALADE_DEBUG,Options
from.patching import patch_empty_vars,patch_method_self_args,patch_unreachable_functions
from.solver import Solver,TimeoutError
from.tokens import UnknownToken
from.vars import DictKeyVar,KwargsUnpackVar,PropVar
from.visitors.analysis import analyze_module
if TYPE_CHECKING:from.program import Program
logger=logging.getLogger(__name__)
_RECURSION_LIMIT=10**4
def analyze_program(program,options=_A):
	D=options;B=program;D=D or Options();A=GlobalState(B,D);F=Importer(A)
	for G in B.initial_imports:
		try:F.import_module(G)
		except ModuleNotFoundError:logger.error("Failed to import initial module '%s'",G)
	E=A.options.root_dir
	if logger.isEnabledFor(logging.INFO):logger.info('Analyzing program with initial modules:\n  %s\n  sys.path: (root: %s)\n  %s',pprint.pformat([B for B in B.initial_imports if B not in A.unresolved_imports],indent=4,compact=True),E,pprint.pformat([os.path.relpath(A,E)for A in B.sys_path],indent=4,compact=True))
	C=Solver(A);L=Operations(C,F)
	def I():
		Q='constraint_setup';K='.';J='propagation'
		while A.worklist:
			match A.worklist.pop():
				case FunctionInfo(QualifiedNode(S,T))as R,M:
					logger.debug('Analyzing function %s @ %s',R.fully_qualified_name,M);N=A.modules[T].visitor;assert N is not _A
					with A.diagnostics.time(Q):N.setup_constraints((S,M))
					with A.diagnostics.time(J):C.propagate()
				case ModuleInfo(D)as F:
					B=F.name
					if K in B:O,X,U=B.rpartition(K);C.add_token_constraint(ModuleToken(B),PropVar(ModuleToken(ModuleIdentifier(O)),U))
					match D.loader:
						case None if D.submodule_search_locations:pass
						case importlib.abc.InspectLoader()as H:
							I=H.get_source(B);assert I is not _A and D.origin is not _A;G=Path(D.origin);A.diagnostics.code_size+=len(I)
							try:
								with A.diagnostics.time('parsing'):V=F.ast=ast.parse(I,G,'exec',feature_version=_A)
							except SyntaxError as P:
								logger.error("Failed to parse module '%s': %s",B,P)
								for W in traceback.format_exception_only(P):logger.error(W.rstrip('\n'))
								continue
							if K in B:A.register_import(B,V,ModuleIdentifier(O))
							logger.info("Analyzing %s module '%s' (%s)",F.kind.name.lower(),B,G.relative_to(E)if G.is_relative_to(E)else G);analyze_module(F,L);logger.info("Propagating tokens for module '%s'",B)
							with A.diagnostics.time(J):C.propagate()
						case importlib.machinery.BuiltinImporter:assert B in sys.builtin_module_names or platform.python_implementation()=='PyPy'and B in('_frozen_importlib','zipimport');logger.debug('Skipping builtin module %s',B)
						case NativeModuleImporter():
							logger.info("Adding tokens for native module '%s'",B)
							with A.diagnostics.time(Q):NativeModuleImporter.setup_module(D,C)
							with A.diagnostics.time(J):C.propagate()
						case H:raise NotImplementedError(f"Unsupported loader: {H!r}")
	if(H:=sys.getrecursionlimit())<_RECURSION_LIMIT:sys.setrecursionlimit(_RECURSION_LIMIT)
	try:
		while A.worklist:
			A.diagnostics.worklist_rounds+=1
			if A.diagnostics.worklist_rounds>1:logger.info('Starting worklist round %d',A.diagnostics.worklist_rounds)
			I();patch_empty_vars(C);patch_method_self_args(C)
			if not A.worklist:patch_unreachable_functions(L)
	except TimeoutError:logger.error('Analysis timed out')
	finally:
		if H<_RECURSION_LIMIT:sys.setrecursionlimit(H)
	if MAMBALADE_DEBUG:_debug_check(C)
	return C
def _debug_check(s):
	for(A,C)in s._tokens.items():
		match A:
			case KwargsUnpackVar():
				for B in C:assert isinstance(B,UnpackedDictToken|UnknownToken),B
			case PropVar(UnpackedDictToken())|DictKeyVar(UnpackedDictToken()):raise AssertionError(f"Unexpected property for UnpackedDictToken: {A}")
			case _:pass