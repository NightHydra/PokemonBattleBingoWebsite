from __future__ import annotations
_F='result'
_E='create_task'
_D='_result'
_C='__init__'
_B='lambda self, /: 1'
_A=None
import logging
from dataclasses import replace
from typing import TYPE_CHECKING,Final
from mambalade.calls import AbstractArgs
from mambalade.infos import Native
from mambalade.listeners import Listener,ListenerKey
from mambalade.natives.builtin_functions import noop
from mambalade.natives.core import Object
from mambalade.natives.helpers import NativeType,generic_class_getitem,native_function,native_method,native_type,return_unknown,unsupported_native
from mambalade.tokens import ImmutableToken,NativeToken,ObjectToken,Token
from mambalade.vars import ConstraintVar,PropVar
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.calls import CallData;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
@native_function('asyncio.run',spec='lambda main, *, debug=False, loop_factory=None: 0')
def run(op,d):
	A=d.args;B=A.args[0]if A.args else _A
	if A.kwargs:
		for(C,D)in A.kwargs:
			if C=='main':
				if B is not _A:op.a.warn_unsupported(d.callnode,'asyncio.run with multiple coroutines');return
				B=D
			elif C=='loop_factory':op.a.warn_unsupported(d.callnode,'asyncio.run with loop_factory')
			elif C is _A:op.a.warn_unsupported(d.callnode,'asyncio.run with mapping unpacking')
	if isinstance(B,Token|ConstraintVar):op.awaitt(B,d)
def _escape(op,d):op.invoke_unknown(d)
@native_type(Object,tname='asyncio.Future',unsupported_methods=['__iter__'])
class Future(NativeType):
	__class_getitem__=generic_class_getitem
	@native_method(_C,spec='lambda self, *, loop=None: 0')
	@staticmethod
	def init(op,d):
		if d.args.kwargs:op.a.warn_unsupported(d.callnode,'asyncio.Future with loop')
	@native_method('set_result',spec='lambda self, result, /: 2')
	@staticmethod
	def set_result(op,d):
		A,B=d.args.args
		if not isinstance(A,ObjectToken)or Future not in A.typ.mro:logger.debug('ignoring asyncio.Future.set_result with non-constant or non-future object %s',A);return
		if isinstance(B,Token|ConstraintVar):op.inclusion_constraint(B,PropVar(A,_D))
	@native_method(_F,spec=_B)
	@staticmethod
	def result(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or Future not in A.typ.mro:logger.debug('ignoring asyncio.Future.result with non-constant or non-future object %s',A);return
		op.return_value(d,PropVar(A,_D))
	@native_method('__await__',spec=_B)
	@staticmethod
	def await_(op,d):Future.call_slot(_F,op,d)
	add_done_callback=unsupported_native('asyncio.Future.add_done_callback',_escape)
	@native_method('get_loop',spec=_B)
	@staticmethod
	def get_loop(op,d):op.return_value(d,_loop_singleton)
@native_type(Future,Object,tname='asyncio.Task',unsupported_methods=['get_context'])
class Task(NativeType):
	set_result=noop;set_exception=noop
	@native_method(_C,spec='lambda self, coro, *, loop=None, name=None, context=None, eager_start=False: 1')
	@staticmethod
	def init(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or Task not in A.typ.mro:logger.debug('ignoring asyncio.Task.__init__ with non-constant or non-task object %s',A);return
		if d.args.kwargs:
			for(B,E)in d.args.kwargs:
				if B=='loop':op.a.warn_unsupported(d.callnode,'asyncio.Task with loop')
				elif B is _A:op.a.warn_unsupported(d.callnode,'asyncio.Task with mapping unpacking')
		if len(d.args.args)>1 and isinstance((C:=d.args.args[1]),Token|ConstraintVar):op.inclusion_constraint(C,PropVar(A,'_coro'));D=ListenerKey(Listener.NATIVE_ASYNCIO_TASK_INIT,parent=d.parent);op.awaitt(C,replace(d,args=AbstractArgs.empty,res=PropVar(A,_D),parent=D))
	@native_method('get_coro',spec=_B)
	@staticmethod
	def get_coro(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or Task not in A.typ.mro:logger.debug('ignoring asyncio.Task.get_coro with non-constant or non-task object %s',A);return
		op.return_value(d,PropVar(A,'_coro'))
@native_type(Object,tname='asyncio.AbstractEventLoop')
class AbstractEventLoop(NativeType):call_soon=unsupported_native('asyncio.AbstractEventLoop.call_soon',_escape)
@native_type(AbstractEventLoop,Object,tname='asyncio.BaseEventLoop')
class BaseEventLoop(NativeType):
	@native_method('create_future',spec='lambda self: 0')
	@staticmethod
	def create_future(op,d):op.return_value(d,Future.new_instance(op,d))
	@native_method(_E,spec='lambda self, coro, *, name=None, context=None: 1')
	@staticmethod
	def create_task(op,d):
		A=d.args
		if len(A.args)==2:op.return_value(d,(B:=Task.new_instance(op,d)));C=ListenerKey(Listener.NATIVE_ASYNCIO_CREATE_TASK,parent=d.parent);Task.call_slot(_C,op,replace(d,args=A.shift().prepend(B),res=_A,parent=C))
		elif A.unpack_iter is not _A:op.a.warn_unsupported(d.callnode,'asyncio.BaseEventLoop.create_task with iterable unpacking')
for method in['set_task_factory','get_task_factory','shutdown_asyncgens','shutdown_default_executor','run_forever','run_until_complete','stop','close','is_closed','is_running','time','call_later','call_at','call_soon','call_soon_threadsafe','run_in_executor','set_default_executor','getaddrinfo','getnameinfo','sock_sendfile','create_connection','sendfile','start_tls','create_datagram_endpoint','create_server','connect_accepted_socket','connect_read_pipe','connect_write_pipe','subprocess_shell','subprocess_exec','get_exception_handler','set_exception_handler','default_exception_handler','call_exception_handler','get_debug','set_debug']:assert method not in BaseEventLoop.known_slots,method;BaseEventLoop.known_slots[method]=unsupported_native(f"asyncio.AbstractEventLoop.{method}",_escape)
@native_type(BaseEventLoop,AbstractEventLoop,Object,tname='asyncio.unix_events._UnixSelectorEventLoop')
class UnixSelectorEventLoop(NativeType):add_signal_handler=unsupported_native('asyncio.unix_events._UnixSelectorEventLoop.add_signal_handler',_escape)
_loop_singleton=ImmutableToken(Native('asyncio.loop'),UnixSelectorEventLoop)
@native_function('asyncio.get_event_loop',spec='lambda: 0')
def get_event_loop(op,d):op.return_value(d,_loop_singleton)
@native_function('asyncio.create_task',spec='lambda coro, *, name=None, context=None: 1')
def create_task(op,d):BaseEventLoop.call_slot(_E,op,replace(d,args=d.args.prepend(_loop_singleton)))
model={'Future':Future,'Task':Task,'run':run,_E:create_task,'SelectorEventLoop':UnixSelectorEventLoop,'AbstractEventLoop':AbstractEventLoop,'get_event_loop':get_event_loop,'get_running_loop':get_event_loop,'new_event_loop':get_event_loop,'set_event_loop':unsupported_native('asyncio.set_event_loop',_escape)}|{A:unsupported_native(f"asyncio.{A}",return_unknown)for A in'ensure_future wrap_future set_event_loop_policy get_event_loop_policy'.split()}