from __future__ import annotations
from typing import TYPE_CHECKING,Final,final
from typing_extensions import override
from mambalade.tokens import ObjectToken
from mambalade.vars import PropVar
from.core import Object
from.helpers import NativeType,native_type
if TYPE_CHECKING:from mambalade.infos import ModuleIdentifier
@native_type(Object)
class Module(NativeType):0
@final
class ModuleToken(ObjectToken):
	typ=Module;immutable=False;__match_args__='id',
	@override
	def __init__(self,id):self.id=id
	@override
	def __str__(self):return f"ModuleToken({self.id})"
	@override
	def __eq__(self,other):A=other;return isinstance(A,ModuleToken)and self.id==A.id
	@override
	def __hash__(self):return hash(self.id)
	@override
	def _lookup_attr(self,attr):return PropVar(self,attr),False