from __future__ import annotations
_C=True
_B=None
_A=False
import ast
from dataclasses import dataclass,field
from typing import Final,NamedTuple,TypeAlias,assert_type,final
from typing_extensions import override
from mambalade import graph
from mambalade.util import TVL
from.transform import BoolEval
@dataclass(slots=_C,eq=_A)
class Jump:target:Final[Block]
@dataclass(slots=_C,eq=_A)
class Branch:test:Final[ast.expr|_B];true:Final[Block];false:Final[Block]
@dataclass(slots=_C)
class SplitClass:cls:Final[ast.ClassDef]
Succ=Jump|Branch
_stmt=ast.stmt|Succ|SplitClass
def succs(node):
	match node:
		case Jump(A):return A,
		case Branch(_,B,C):return B,C
		case ast.Return()|ast.Raise():return()
		case _:assert_type(node,ast.stmt|SplitClass);return
@dataclass(slots=_C,eq=_A)
class Block:
	stmts:Final[list[_stmt]]=field(default_factory=list,repr=_A)
	def edges(B):A=succs(B.stmts[-1]);assert A is not _B;return A
@dataclass(slots=_C)
class CFG:
	function:Final[ast.FunctionDef|ast.AsyncFunctionDef];entry:Final[Block]=field(default_factory=Block,init=_A);blocks:Final[list[Block]]=field(default_factory=list,init=_A)
	def clean(A):
		def B(block):
			A=block
			for(B,C)in enumerate(A.stmts):
				if(D:=succs(C))is not _B:del A.stmts[B+1:];return D
			raise AssertionError('Unterminated block')
		A.blocks.extend(graph.bfs(B,(A.entry,)))
class _Loop(NamedTuple):hdr:Block;merge:Block
@final
class CFGBuilder(ast.NodeVisitor):
	def __init__(A,function,beval):A.cfg=CFG(function);A.beval=beval;A.loops=[];A.current_block=A.cfg.entry
	def build(A):
		for B in A.cfg.function.body:A.visit(B)
		A.current_block.stmts.append(ast.Return());A.cfg.clean();return A.cfg
	@override
	def generic_visit(self,node):
		if isinstance(node,ast.stmt):self.current_block.stmts.append(node)
	def _visit_and_jump(A,block,stmts,target):
		A.current_block=block
		for B in stmts:A.visit(B)
		A.current_block.stmts.append(Jump(target))
	def visit_If(B,node):
		A=node
		if(F:=B.beval.eval(A.test))is not TVL.MAYBE:
			B.current_block.stmts.append(ast.Expr(A.test))
			for G in A.body if F is TVL.TRUE else A.orelse:B.visit(G)
			return
		H=B.current_block;C=Block()
		if A.orelse:D=Block();B._visit_and_jump(D,A.orelse,C)
		else:D=C
		E=Block();H.stmts.append(Branch(A.test,E,D));B._visit_and_jump(E,A.body,C);B.current_block=C
	def _visit_loop(A,node):
		B=node;F,D=Block(),Block()
		if isinstance(B,ast.While):E=B.test
		else:E=_B;A.current_block.stmts.append(ast.Expr(B.iter));F.stmts.append(ast.Assign([B.target],ast.Constant(_B)))
		if not A.current_block.stmts and A.current_block is not A.cfg.entry:C=A.current_block
		else:C=Block();A.current_block.stmts.append(Jump(C))
		D=Block()
		if B.orelse:G=Block();A._visit_and_jump(G,B.orelse,D)
		else:G=D
		if E is not _B and(I:=A.beval.eval(E))is not TVL.MAYBE:C.stmts.append(ast.Expr(E));H=Jump(F if I is TVL.TRUE else G)
		else:H=Branch(E,F,G)
		C.stmts.append(H);A.loops.append(_Loop(C,D));A._visit_and_jump(F,B.body,C);A.loops.pop();A.current_block=D
	visit_For=_visit_loop;visit_AsyncFor=_visit_loop;visit_While=_visit_loop
	@override
	def visit_Break(self,node):B,A=self.loops[-1];self.current_block.stmts.append(Jump(A))
	@override
	def visit_Continue(self,node):A,B=self.loops[-1];self.current_block.stmts.append(Jump(A))
	@override
	def visit_ClassDef(self,node):
		B=self;A=node;C=[B for A in(A.decorator_list,A.bases)for B in A];C.extend(A.value for A in A.keywords)
		if C:B.current_block.stmts.append(ast.Expr(ast.Tuple(C,ctx=ast.Load())))
		for D in A.body:B.visit(D)
		B.current_block.stmts.append(SplitClass(A))
	def _visit_try(A,node):
		A.current_block.stmts.append(node)
		if A.loops:
			D,E=A.loops[-1];C=_LoopEffectsVisitor();C.visit(node)
			if C.has_break:B=Block();A.current_block.stmts.append(Branch(_B,E,B));A.current_block=B
			if C.has_continue:B=Block();A.current_block.stmts.append(Branch(_B,D,B));A.current_block=B
	visit_Try=_visit_try;visit_TryStar=_visit_try;visit_With=_visit_try;visit_AsyncWith=_visit_try
@final
class _LoopEffectsVisitor(ast.NodeVisitor):
	def __init__(A):A.has_break=_A;A.has_continue=_A
	@override
	def visit(self,node):
		B=node;A=self
		match B:
			case ast.Break():A.has_break=_C
			case ast.Continue():A.has_continue=_C
			case ast.For()|ast.AsyncFor()|ast.While():
				for C in B.orelse:A.visit(C)
			case ast.FunctionDef()|ast.AsyncFunctionDef()|ast.ClassDef():pass
			case ast.expr():pass
			case _:A.generic_visit(B)
if __name__=='__main__':
	import argparse,sys;from pathlib import Path;parser=argparse.ArgumentParser();parser.add_argument('files',type=Path,nargs='+',help='The files to analyze');args=parser.parse_args();idx={}
	def geti(d):return idx.setdefault(d,len(idx))
	for file in args.files:
		print(f"Processing {file}",file=sys.stderr)
		with file.open('r')as f:
			try:module=ast.parse(f.read(),filename=str(file))
			except SyntaxError as e:print(f"Syntax error in {file}: {e}",file=sys.stderr);continue
		i=0;print('digraph G {');extra=[]
		for node in ast.walk(module):
			if isinstance(node,ast.FunctionDef|ast.AsyncFunctionDef):
				cfg=CFGBuilder(node,BoolEval()).build();print(f'  subgraph cluster_{i} {{ label = "{node.name}";');i+=1
				for block in cfg.blocks:
					print(f'    subgraph cluster_b{geti(block)} {{ label = "b{geti(block)}";')
					for(j,stmt)in enumerate(block.stmts):
						print(f'    {geti(stmt)} [label="{type(stmt).__name__}"];')
						if j>0:print(f"    {geti(block.stmts[j-1])} -> {geti(stmt)};")
						extra.extend(f"    {geti(stmt)} -> {geti(A.stmts[0])};\n"for A in succs(stmt)or())
					print('    }')
				print('  }')
		print(*extra,sep='',end='');print('}')