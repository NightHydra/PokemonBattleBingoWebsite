from __future__ import annotations
_I='__await__'
_H='send throw close'
_G='lambda self, function, /: 2'
_F='__init__'
_E='lambda self, instance, owner=None, /: 2'
_D='__call__'
_C='__get__'
_B=False
_A='lambda self, /: 1'
import ast,logging,typing
from dataclasses import replace
from typing import TYPE_CHECKING,Final,assert_type,final
from typing_extensions import override
from mambalade.asthelpers import FunctionNode
from mambalade.contexts import Context,EmptyContext
from mambalade.infos import CallEdgeKind,NodeSource,QualifiedNode,SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.token_utils import type_has_attr
from mambalade.tokens import AccessPathToken,ImmutableToken,ObjectToken,Token,UnknownToken
from mambalade.util import TVL,CacheHashMixin
from mambalade.vars import ConstraintVar,PropVar
from.builtin_functions import noop
from.core import Object
from.core_tokens import ClassMethodToken,NativeFunctionToken
from.helpers import NativeType,native_function,native_method,native_type
if TYPE_CHECKING:from mambalade.calls import CallData;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
@native_function('__call__ wrapper',spec='lambda fun, *args, **kwargs: 1')
def call_wrapper(op,d):
	A=d.args
	if isinstance((C:=A.args[0]),ConstraintVar|Token):
		B=ListenerKey(Listener.NATIVE_WRAPPER__CALL__DISPATCH,parent=d.parent);D=replace(d,args=A.shift(),parent=B)
		def E(ft):
			if isinstance(ft,(FunctionToken,NativeFunctionToken,UnknownToken,AccessPathToken,BoundMethodToken)):op.invoke_object(ft,D)
			elif TYPE_CHECKING:assert_type(ft,ObjectToken)
		op.solver.add_forall_constraint(C,B,E)
@native_type(Object)
class BoundMethod(NativeType):__call__=call_wrapper;__new__=noop
@final
class BoundMethodToken(ObjectToken,CacheHashMixin):
	typ=BoundMethod;immutable=True;__match_args__='fun','slf'
	@override
	def __init__(self,fun,slf):super().__init__();self.fun=fun;self.slf=slf
	@override
	def __str__(self):return f"BoundFunctionToken({self.fun}, {self.slf})"
	@override
	def __eq__(self,other):A=other;return isinstance(A,BoundMethodToken)and(self.fun,self.slf)==(A.fun,A.slf)
	@override
	def _compute_hash(self):A=self;return hash((type(A),A.fun,A.slf))
	@override
	def _lookup_attr(self,attr):
		if attr=='__self__':return self.slf,True
		if attr=='__func__':return self.fun,True
		return None,_B
def _make_bound_methods(op,fv,slf,d):
	C=slf;B=op;assert isinstance(C,ObjectToken)
	def A(ft):
		A=ft
		match A:
			case _ if A==call_wrapper:B.return_value(d,C)
			case ObjectToken(D)if type_has_attr(D,_D)is not TVL.FALSE:
				if isinstance(A,BoundMethodToken)and isinstance(A.fun,BoundMethodToken):A=A.fun
				B.return_value(d,BoundMethodToken(A,C))
			case UnknownToken():B.return_value(d,A);B.register_escaping(C,d)
			case _:logger.debug('Unsupported token for bound method: %s',A)
	B.forall_constraint_uncached(fv,ListenerKey(Listener.OP_MAKE_BOUND_METHODS,token=C,parent=d.parent),A)
@native_type(Object)
class Function(NativeType):
	__new__=noop;__call__=call_wrapper
	@native_method(_C,spec=_E)
	@staticmethod
	def get(op,d):
		A=op;D=d.args;B,C,*F=D.args
		if not isinstance(B,ObjectToken):logger.debug('Ignoring call to function.__get__ with non-function object %s',B);return
		match C:
			case ObjectToken():_make_bound_methods(A,B,C,d)
			case None:A.return_value(d,B)
			case UnknownToken():A.return_value(d,C)
			case AccessPathToken():pass
			case ConstraintVar():
				A.return_value(d,B)
				def E(t):
					match t:
						case ObjectToken():_make_bound_methods(A,B,t,d)
						case UnknownToken():A.return_value(d,t);A.register_escaping(B,d)
						case AccessPathToken():pass
				A.forall_constraint_uncached(C,ListenerKey(Listener.NATIVE_FUNCTION__GET__,parent=d.parent),E)
			case str()|int()|ast.Slice():pass
NativeFunctionToken.typ=Function
@final
class FunctionToken(ObjectToken,CacheHashMixin):
	typ=Function;immutable=_B;__match_args__='fun','context'
	@override
	def __init__(self,fun,context):super().__init__();self.fun=fun;self.context=context
	@override
	def __str__(self):return f"FunctionToken({self.fun} @ {self.context})"
	@override
	def __eq__(self,other):A=other;return isinstance(A,FunctionToken)and(self.fun,self.context)==(A.fun,A.context)
	@override
	def _compute_hash(self):return hash((self.fun,self.context))
	@override
	def _lookup_attr(self,attr):return PropVar(self,attr),_B
@native_type(Object)
class ClassMethod(NativeType):
	@native_method(_F,spec=_G)
	@staticmethod
	def init(op,d):
		A,B=d.args.args;assert isinstance(A,ObjectToken)and ClassMethod in A.typ.mro
		if isinstance(B,Token|ConstraintVar):op.inclusion_constraint(B,PropVar(A,SynthProp.CLASSMETHOD_FUNCTION))
	@native_method(_C,spec=_E)
	@staticmethod
	def get(op,d):
		A=op;C=d.args;assert len(C.args)>=2;B,E,*F=C.args;assert isinstance(B,ObjectToken)and ClassMethod in B.typ.mro
		if isinstance(B,ClassMethodToken):D=B.fun
		else:D=PropVar(B,SynthProp.CLASSMETHOD_FUNCTION)
		if F and isinstance((G:=F[0]),Token|ConstraintVar):A.forall_constraint_uncached(G,ListenerKey(Listener.NATIVE_CLASSMETHOD__GET__OWNER,parent=d.parent),lambda slf:_make_bound_methods(A,D,slf,d))
		elif C.unpack_iter is not None:A.a.warn_unsupported(d.callnode,'classmethod.__get__ with iterable unpacking')
		if isinstance(E,Token|ConstraintVar):
			def H(t):assert isinstance(t,ObjectToken);_make_bound_methods(A,D,t.typ,d)
			A.forall_constraint_uncached(E,ListenerKey(Listener.NATIVE_CLASSMETHOD__GET__INSTANCE,parent=d.parent),H)
ClassMethodToken.typ=ClassMethod
@native_type(Object)
class StaticMethod(NativeType):
	@native_method(_F,spec=_G)
	@staticmethod
	def init(op,d):
		A,B=d.args.args;assert isinstance(A,ObjectToken)and StaticMethod in A.typ.mro
		if isinstance(B,Token|ConstraintVar):op.inclusion_constraint(B,PropVar(A,SynthProp.STATICMETHOD_FUNCTION))
	@native_method(_C,spec='lambda self, instance, owner=None, /: 1')
	@staticmethod
	def get(op,d):A,*B=d.args.args;assert isinstance(A,ObjectToken)and StaticMethod in A.typ.mro;op.return_value(d,PropVar(A,SynthProp.STATICMETHOD_FUNCTION))
	@native_method(_D,spec='lambda self, /, *args, **kwargs: 1')
	@staticmethod
	def call(op,d):B=d.args;A=B.args[0];assert isinstance(A,ObjectToken)and StaticMethod in A.typ.mro;C=ListenerKey(Listener.NATIVE_STATICMETHOD__CALL__,parent=d.parent);op.invoke_object(PropVar(A,SynthProp.STATICMETHOD_FUNCTION),replace(d,args=B.shift(),parent=C))
@native_type(Object,unsupported_methods=_H.split())
class Generator(NativeType):
	__new__=noop
	@native_method('__iter__',spec=_A)
	@staticmethod
	def iter(op,d):
		if isinstance((A:=d.args.args[0]),Token|ConstraintVar):op.return_value(d,A)
	@native_method('__next__',spec=_A)
	@staticmethod
	def next(op,d):
		if isinstance((A:=d.args.args[0]),Token|ConstraintVar):
			def B(t):
				match t:
					case ImmutableToken(_,A)if A is Generator:op.return_value(d,PropVar(t,SynthProp.GENERATOR_ELEMENT))
					case UnknownToken():op.return_value(d,t)
					case AccessPathToken():pass
					case _:assert_type(t,ObjectToken);logger.debug('Discarding call to generator.__next__ with non-generator object %s',t)
			op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_GENERATOR__NEXT__,parent=d.parent),B)
@native_type(Object,tname='async_generator_asend')
class AsyncGeneratorAsend(NativeType):
	__new__=noop
	@native_method(_I,spec=_A)
	@staticmethod
	def await_(op,d):
		match d.args.args[0]:
			case ImmutableToken(QualifiedNode(ast.AsyncFunctionDef())as A,B)if B is AsyncGeneratorAsend:op.return_value(d,PropVar(ImmutableToken(A,Generator),SynthProp.GENERATOR_ELEMENT))
			case C:logger.debug('Discarding call to async_generator_asend.__await__ with non-async-generator-asend object %s',C)
@native_type(Object,tname='async_generator',unsupported_methods='asend athrow aclose'.split())
class AsyncGenerator(NativeType):
	__new__=noop
	@native_method('__aiter__',spec=_A)
	@staticmethod
	def aiter(op,d):
		if isinstance((A:=d.args.args[0]),Token|ConstraintVar):op.return_value(d,A)
	@native_method('__anext__',spec=_A)
	@staticmethod
	def anext(op,d):
		if not isinstance((A:=d.args.args[0]),Token|ConstraintVar):return
		def B(t):
			match t:
				case ImmutableToken(QualifiedNode(ast.AsyncFunctionDef())as A,B)if B is AsyncGenerator:op.return_value(d,ImmutableToken(A,AsyncGeneratorAsend))
				case UnknownToken():op.return_value(d,t)
				case AccessPathToken():pass
				case _:assert_type(t,ObjectToken);logger.debug('Discarding call to async_generator.__anext__ with non-async-generator object %s',t)
		op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_ASYNC_GENERATOR__ANEXT__,parent=d.parent),B)
@native_type(Object,unsupported_methods=_H.split())
class Coroutine(NativeType):
	__new__=noop
	@native_method(_I,spec=_A)
	@staticmethod
	def await_(op,d):
		A=op
		if isinstance((B:=d.args.args[0]),Token|ConstraintVar):
			def C(t):
				match t:
					case ImmutableToken(B,C)if C is Coroutine:
						A.return_value(d,PropVar(t,SynthProp.COROUTINE_ELEMENT))
						if A.a.options.coroutine_edges:assert isinstance(B,QualifiedNode)and isinstance(B.node,FunctionNode);A.a.register_call_edge(d.caller,d.callnode.node,NodeSource(typing.cast('QualifiedNode[FunctionNode]',B),EmptyContext()),kind=CallEdgeKind.COROUTINE)
					case UnknownToken():A.return_value(d,t)
					case AccessPathToken():pass
					case _:assert_type(t,ObjectToken);logger.debug('Discarding call to coroutine.__await__ with non-coroutine object %s',t)
			A.forall_constraint_uncached(B,ListenerKey(Listener.NATIVE_COROUTINE__AWAIT__,parent=d.parent),C)