from __future__ import annotations
import ast,logging
from typing import TYPE_CHECKING
from.tokens import ImmutableToken,Token,TypeToken
from.util import TVL
if TYPE_CHECKING:from collections.abc import Iterable;from.calls import AbstractArg;from.vars import ConstraintVar
logger=logging.getLogger(__name__)
def lookup_attr_mro(typ_or_mro,attr):return lookup_attr_mro2(typ_or_mro,attr)[0]
def lookup_attr_mro2(typ_or_mro,attr):
	C=attr;A=typ_or_mro
	if isinstance(A,TypeToken):B=A.mro;logger.debug('Looking up property %s on %s (mro: %s)',C,A,B)
	else:B=A;logger.debug('Looking up property %s on mro: %s',C,B)
	D=False;E=[]
	for G in B:
		F,D=G.lookup_attr(C)
		if F is not None:E.append(F)
		if D:break
	logger.debug('Lookup result: %s',E);return E,D
def type_has_attr(t,attr):
	A=TVL.FALSE
	for B in t.mro:
		C,D=B.lookup_attr(attr)
		if C is not None:
			if D:return TVL.TRUE
			A=TVL.MAYBE
	return A
def object_hashable(t):
	from.natives import Dict,List,Set
	match t:
		case ast.Slice():return TVL.FALSE
		case int()|str()|None:return TVL.TRUE
		case ImmutableToken(_,A)if A in(List,Dict,Set):return TVL.FALSE
		case _:return TVL.MAYBE